# vRun APK Build Instructions

This document provides instructions on how to build the release APK for the vRun game project.

## Prerequisites

1.  **Flutter SDK:** Ensure you have the Flutter SDK installed and configured correctly on your system. You can download it from the official Flutter website: [https://flutter.dev/docs/get-started/install](https://flutter.dev/docs/get-started/install)
2.  **Android SDK:** Make sure you have the Android SDK installed, along with the necessary build tools and platform tools. Flutter setup usually guides you through this (`flutter doctor` command).
3.  **Project Files:** You need the complete vRun project source code (provided in the zip archive).

## Build Steps

1.  **Extract Project:** Extract the `vrun_project.zip` (or similar named archive) to a location on your computer.

2.  **Open Terminal:** Open your terminal or command prompt.

3.  **Navigate to Project Directory:** Change your current directory to the root of the extracted vRun project folder. For example:
    ```bash
    cd path/to/your/extracted/vrun
    ```

4.  **Get Dependencies:** Run the following command to fetch all the required project dependencies:
    ```bash
    flutter pub get
    ```

5.  **Build Release APK:** Execute the command below to build the release version of the APK. This process might take several minutes.
    ```bash
    flutter build apk --release
    ```

6.  **Locate APK:** Once the build is successful, the release APK file will be located in the following directory within your project folder:
    ```
    build/app/outputs/flutter-apk/app-release.apk
    ```
    You can copy this `app-release.apk` file and install it on an Android device.

## Troubleshooting

*   **Build Errors:** If you encounter build errors, especially related to dependencies or compatibility issues (like the ones experienced during development), try upgrading the dependencies first:
    ```bash
    flutter pub upgrade
    ```
    Then, attempt the build command (`flutter build apk --release`) again.
*   **Flutter Doctor:** Run `flutter doctor -v` to check if your Flutter and Android SDK setup is correct and if any components are missing or need configuration.
*   **Clean Build:** Sometimes, cleaning the project can resolve issues:
    ```bash
    flutter clean
    flutter pub get
    flutter build apk --release
    ```

If you continue to face issues, please refer to the specific error messages and consult the Flutter and Flame documentation or community forums.
