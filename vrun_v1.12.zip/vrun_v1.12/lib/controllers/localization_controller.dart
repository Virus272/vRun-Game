import 'package:get/get.dart';
import '../services/localization_service.dart';
import '../services/storage_service.dart';

class LocalizationController extends GetxController {
  // Observable variables
  final RxString _currentLanguage = 'en'.obs;
  
  // Getters
  String get currentLanguage => _currentLanguage.value;
  
  // Storage service
  final StorageService _storageService = Get.find<StorageService>();
  
  @override
  void onInit() {
    super.onInit();
    // Load saved language preference
    loadSavedLanguage();
  }
  
  // Load saved language from storage
  Future<void> loadSavedLanguage() async {
    final String? savedLanguage = await _storageService.getLanguage();
    if (savedLanguage != null) {
      _currentLanguage.value = savedLanguage;
      updateLocale(savedLanguage);
    }
  }
  
  // Change language
  Future<void> changeLanguage(String languageCode) async {
    _currentLanguage.value = languageCode;
    await _storageService.setLanguage(languageCode);
    updateLocale(languageCode);
  }
  
  // Update app locale
  void updateLocale(String languageCode) {
    LocalizationService.changeLocale(languageCode);
  }
}
