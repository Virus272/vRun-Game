import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/enums.dart';

class GameController extends GetxController {
  // Game state
  final RxInt _currentLevel = 1.obs;
  final RxInt _highestUnlockedLevel = 1.obs;
  final RxInt _score = 0.obs;
  final Rx<GameState> _gameState = GameState.loading.obs;
  final Rx<ControlMethod> _controlMethod = ControlMethod.auto.obs;

  // Power-up states
  final RxBool _hasShield = false.obs;
  final RxBool _hasSlowMotion = false.obs;

  // Settings states (assuming these are managed elsewhere, e.g., SettingsController)
  // If GameController should manage them, add RxBool here.
  // For now, let's assume they come from SettingsController via Get.find()
  // final RxBool _musicEnabled = true.obs; // Example if managed here

  // Getters
  int get currentLevel => _currentLevel.value;
  int get highestUnlockedLevel => _highestUnlockedLevel.value;
  int get score => _score.value;
  GameState get gameState => _gameState.value;
  ControlMethod get controlMethod => _controlMethod.value;
  bool get hasShield => _hasShield.value;
  bool get hasSlowMotion => _hasSlowMotion.value;

  // Rx Getters for direct observation in other classes
  Rx<GameState> get gameStateObs => _gameState;
  Rx<ControlMethod> get controlMethodObs => _controlMethod;
  RxBool get hasShieldObs => _hasShield;
  RxBool get hasSlowMotionObs => _hasSlowMotion;
  // Expose settings if managed here or provide access via SettingsController

  // Shared preferences instance
  late SharedPreferences _prefs;

  @override
  void onInit() async {
    super.onInit();

    // Initialize shared preferences
    _prefs = await SharedPreferences.getInstance();

    // Load saved game data
    _loadGameData();
  }

  // Load game data from shared preferences
  void _loadGameData() {
    _highestUnlockedLevel.value = _prefs.getInt('highestUnlockedLevel') ?? 1;

    // Load control method (ensure key matches SettingsController if shared)
    String controlMethodStr = _prefs.getString('controlMethod') ?? 'auto';
    _controlMethod.value = controlMethodStr == 'manual' ? ControlMethod.manual : ControlMethod.auto;

    // Load other settings like musicEnabled if managed here
    // _musicEnabled.value = _prefs.getBool('musicEnabled') ?? true;
  }

  // Set current level
  void setLevel(int level) {
    _currentLevel.value = level;
  }

  // Unlock next level
  void unlockNextLevel() {
    if (_currentLevel.value >= _highestUnlockedLevel.value) {
      _highestUnlockedLevel.value = _currentLevel.value + 1;
      _prefs.setInt('highestUnlockedLevel', _highestUnlockedLevel.value);
    }
  }

  // Set game state
  void setGameState(GameState state) {
    _gameState.value = state;
  }

  // Set control method
  void setControlMethod(ControlMethod method) {
    _controlMethod.value = method;
    _prefs.setString('controlMethod', method == ControlMethod.manual ? 'manual' : 'auto');
  }

  // Set score
  void setScore(int score) {
    _score.value = score;
  }

  // Increment score
  void incrementScore(int points) {
    _score.value += points;
  }

  // Set shield status
  void setShield(bool hasShield) {
    _hasShield.value = hasShield;
  }

  // Set slow motion status
  void setSlowMotion(bool hasSlowMotion) {
    _hasSlowMotion.value = hasSlowMotion;
  }

  // Reset level progress (for testing)
  void resetProgress() {
    _highestUnlockedLevel.value = 1;
    _prefs.setInt('highestUnlockedLevel', 1);
  }
}

