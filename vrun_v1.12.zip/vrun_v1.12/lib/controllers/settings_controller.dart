import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/enums.dart';
import '../services/audio_manager.dart';

class SettingsController extends GetxController {
  // Reactive variables
  final RxString controlMethod = 'auto'.obs;
  final RxBool soundEnabled = true.obs;
  final RxBool musicEnabled = true.obs;
  final RxDouble sfxVolume = 0.7.obs;
  final RxDouble musicVolume = 0.5.obs;
  
  // Audio manager reference
  final AudioManager _audioManager = AudioManager();
  
  // Shared preferences instance
  late SharedPreferences _prefs;
  
  // Rx variables for GetX binding
  RxInterface get rx => Rx(this);
  
  @override
  void onInit() async {
    super.onInit();
    
    // Initialize shared preferences
    _prefs = await SharedPreferences.getInstance();
    
    // Load saved settings
    _loadSettings();
  }
  
  // Load settings from shared preferences
  void _loadSettings() {
    controlMethod.value = _prefs.getString('controlMethod') ?? 'auto';
    soundEnabled.value = _prefs.getBool('soundEnabled') ?? true;
    musicEnabled.value = _prefs.getBool('musicEnabled') ?? true;
    sfxVolume.value = _prefs.getDouble('sfxVolume') ?? 0.7;
    musicVolume.value = _prefs.getDouble('musicVolume') ?? 0.5;
    
    // Update audio manager with loaded settings
    if (musicEnabled.value) {
      _audioManager.updateMusicVolume(musicVolume.value);
    }
  }
  
  // Set control method
  void setControlMethod(String method) {
    controlMethod.value = method;
    _prefs.setString('controlMethod', method);
  }
  
  // Get control method as enum
  ControlMethod getControlMethodEnum() {
    return controlMethod.value == 'auto' ? ControlMethod.auto : ControlMethod.manual;
  }
  
  // Set sound enabled
  void setSoundEnabled(bool enabled) {
    soundEnabled.value = enabled;
    _prefs.setBool('soundEnabled', enabled);
  }
  
  // Set music enabled
  void setMusicEnabled(bool enabled) {
    musicEnabled.value = enabled;
    _prefs.setBool('musicEnabled', enabled);
    
    // Update audio manager
    if (enabled) {
      _audioManager.resumeBackgroundMusic();
    } else {
      _audioManager.pauseBackgroundMusic();
    }
  }
  
  // Set sound effects volume
  void setSfxVolume(double volume) {
    sfxVolume.value = volume;
    _prefs.setDouble('sfxVolume', volume);
  }
  
  // Set music volume
  void setMusicVolume(double volume) {
    musicVolume.value = volume;
    _prefs.setDouble('musicVolume', volume);
    
    // Update audio manager
    _audioManager.updateMusicVolume(volume);
  }
}
