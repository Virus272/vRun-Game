import 'package:flame/flame.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:get/get.dart';
import 'controllers/game_controller.dart';
import 'controllers/localization_controller.dart';
import 'controllers/settings_controller.dart';
import 'core/enums.dart';
import 'core/vrun_game.dart';
import 'overlays/game_over_menu.dart';
import 'overlays/gameplay_overlay.dart';
import 'overlays/level_select.dart';
import 'overlays/main_menu.dart';
import 'overlays/pause_menu.dart';
import 'overlays/settings_menu.dart';
import 'overlays/splash_screen.dart';
import 'overlays/victory_menu.dart';
import 'services/audio_service.dart';
import 'services/localization_service.dart';
import 'services/storage_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Initialize Flame
  await Flame.device.fullScreen();
  await Flame.device.setPortrait();
  
  // Initialize localization
  await LocalizationService.init();
  
  // Initialize services
  await initServices();
  
  runApp(const MyApp());
}

Future<void> initServices() async {
  // Initialize storage service
  await Get.putAsync(() => StorageService().init());
  
  // Initialize controllers
  Get.put(GameController());
  Get.put(SettingsController());
  Get.put(LocalizationController());
  
  // Initialize audio service (after settings controller)
  await Get.putAsync(() => AudioService().init());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'vRun',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.grey,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      // Localization
      locale: LocalizationService.locale,
      fallbackLocale: LocalizationService.fallbackLocale,
      translations: LocalizationService(),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: LocalizationService.locales,
      
      home: const GameScreen(),
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late VRunGame _game;
  final GameController _gameController = Get.find<GameController>();

  @override
  void initState() {
    super.initState();
    _game = VRunGame();
    
    // Set initial game state
    _gameController.setGameState(GameState.loading);
    
    // After a short delay, change to menu state
    Future.delayed(const Duration(seconds: 3), () {
      _gameController.setGameState(GameState.menu);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GameWidget(
        game: _game,
        overlayBuilderMap: {
          'splash': (context, game) => const SplashScreenOverlay(),
          'main_menu': (context, game) => const MainMenuOverlay(),
          'settings': (context, game) => SettingsMenu(),
          'level_select': (context, game) => const LevelSelectOverlay(),
          'gameplay': (context, game) => const GameplayOverlay(),
          'pause': (context, game) => const PauseMenuOverlay(),
          'game_over': (context, game) => const GameOverOverlay(),
          'victory': (context, game) => const VictoryOverlay(),
        },
        initialActiveOverlays: const ['splash'],
        loadingBuilder: (context) => const Center(
          child: CircularProgressIndicator(),
        ),
        errorBuilder: (context, error) => Center(
          child: Text(
            'Error: $error',
            style: const TextStyle(color: Colors.red),
          ),
        ),
      ),
    );
  }
  
  @override
  void dispose() {
    _game.removeFromParent();
    super.dispose();
  }
}
