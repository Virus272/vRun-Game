import '../core/enums.dart';

class LevelData {
  final int levelNumber;
  final String name;
  final double gameSpeed;
  final List<TrapData> traps;
  final List<PowerUpData> powerUps;
  final double levelLength; // in pixels
  
  LevelData({
    required this.levelNumber,
    required this.name,
    required this.gameSpeed,
    required this.traps,
    required this.powerUps,
    required this.levelLength,
  });
  
  // Factory method to create levels
  static LevelData createLevel(int levelNumber) {
    switch (levelNumber) {
      case 1:
        return _createLevel1();
      case 2:
        return _createLevel2();
      case 3:
        return _createLevel3();
      case 4:
        return _createLevel4();
      case 5:
        return _createLevel5();
      default:
        // For levels beyond 5, generate procedurally with increasing difficulty
        return _createProceduralLevel(levelNumber);
    }
  }
  
  // Level 1: Tutorial level with basic obstacles
  static LevelData _createLevel1() {
    return LevelData(
      levelNumber: 1,
      name: 'First Steps',
      gameSpeed: 1.0,
      levelLength: 3000,
      traps: [
        // Simple spike pattern to teach jumping
        TrapData(type: TrapType.spike, position: const Vector2(500, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.spike, position: const Vector2(800, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.spike, position: const Vector2(1100, 0), size: const Vector2(50, 30)),
        
        // Simple blade to teach timing
        TrapData(type: TrapType.blade, position: const Vector2(1500, 0), size: const Vector2(60, 60)),
        
        // Low laser to teach bowing
        TrapData(type: TrapType.laser, position: const Vector2(1900, 50), size: const Vector2(100, 10)),
        
        // Final challenge combining spike and blade
        TrapData(type: TrapType.spike, position: const Vector2(2300, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.blade, position: const Vector2(2500, 0), size: const Vector2(60, 60)),
      ],
      powerUps: [
        // Shield power-up to teach power-up collection
        PowerUpData(type: PowerUpType.shield, position: const Vector2(1300, 50)),
      ],
    );
  }
  
  // Level 2: Introduces more complex patterns
  static LevelData _createLevel2() {
    return LevelData(
      levelNumber: 2,
      name: 'Double Trouble',
      gameSpeed: 1.2,
      levelLength: 3500,
      traps: [
        // Double spike pattern to teach double jumping
        TrapData(type: TrapType.spike, position: const Vector2(400, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.spike, position: const Vector2(500, 0), size: const Vector2(50, 30)),
        
        // Blade followed by spike
        TrapData(type: TrapType.blade, position: const Vector2(900, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.spike, position: const Vector2(1050, 0), size: const Vector2(50, 30)),
        
        // Introduces falling platform
        TrapData(type: TrapType.fallingPlatform, position: const Vector2(1400, 0), size: const Vector2(100, 20)),
        
        // Laser pattern
        TrapData(type: TrapType.laser, position: const Vector2(1800, 50), size: const Vector2(100, 10)),
        TrapData(type: TrapType.laser, position: const Vector2(2000, 20), size: const Vector2(100, 10)),
        
        // Complex pattern with multiple obstacles
        TrapData(type: TrapType.spike, position: const Vector2(2400, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.blade, position: const Vector2(2600, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.laser, position: const Vector2(2800, 50), size: const Vector2(100, 10)),
      ],
      powerUps: [
        // Shield power-up
        PowerUpData(type: PowerUpType.shield, position: const Vector2(1200, 50)),
        // Slow motion power-up
        PowerUpData(type: PowerUpType.slowMotion, position: const Vector2(2200, 50)),
      ],
    );
  }
  
  // Level 3: Introduces crumbling platforms and more complex patterns
  static LevelData _createLevel3() {
    return LevelData(
      levelNumber: 3,
      name: 'Crumbling Path',
      gameSpeed: 1.4,
      levelLength: 4000,
      traps: [
        // Spike pattern
        TrapData(type: TrapType.spike, position: const Vector2(300, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.spike, position: const Vector2(450, 0), size: const Vector2(50, 30)),
        
        // Introduces crumbling platform
        TrapData(type: TrapType.crumblingPlatform, position: const Vector2(800, 0), size: const Vector2(120, 20)),
        
        // Blade pattern
        TrapData(type: TrapType.blade, position: const Vector2(1100, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.blade, position: const Vector2(1300, 0), size: const Vector2(60, 60)),
        
        // Complex pattern with falling platform and laser
        TrapData(type: TrapType.fallingPlatform, position: const Vector2(1700, 0), size: const Vector2(100, 20)),
        TrapData(type: TrapType.laser, position: const Vector2(1900, 50), size: const Vector2(100, 10)),
        
        // Challenging sequence
        TrapData(type: TrapType.spike, position: const Vector2(2300, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.crumblingPlatform, position: const Vector2(2500, 0), size: const Vector2(120, 20)),
        TrapData(type: TrapType.blade, position: const Vector2(2700, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.laser, position: const Vector2(3000, 30), size: const Vector2(100, 10)),
        TrapData(type: TrapType.spike, position: const Vector2(3200, 0), size: const Vector2(50, 30)),
      ],
      powerUps: [
        // Shield power-up
        PowerUpData(type: PowerUpType.shield, position: const Vector2(1000, 50)),
        // Slow motion power-up
        PowerUpData(type: PowerUpType.slowMotion, position: const Vector2(2000, 50)),
        // Another shield for the final challenge
        PowerUpData(type: PowerUpType.shield, position: const Vector2(2900, 50)),
      ],
    );
  }
  
  // Level 4: Fast-paced with complex trap combinations
  static LevelData _createLevel4() {
    return LevelData(
      levelNumber: 4,
      name: 'Speed Run',
      gameSpeed: 1.6,
      levelLength: 4500,
      traps: [
        // Quick succession of spikes
        TrapData(type: TrapType.spike, position: const Vector2(300, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.spike, position: const Vector2(400, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.spike, position: const Vector2(600, 0), size: const Vector2(50, 30)),
        
        // Blade pattern
        TrapData(type: TrapType.blade, position: const Vector2(900, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.blade, position: const Vector2(1050, 0), size: const Vector2(60, 60)),
        
        // Complex laser pattern
        TrapData(type: TrapType.laser, position: const Vector2(1400, 20), size: const Vector2(100, 10)),
        TrapData(type: TrapType.laser, position: const Vector2(1500, 50), size: const Vector2(100, 10)),
        TrapData(type: TrapType.laser, position: const Vector2(1700, 30), size: const Vector2(100, 10)),
        
        // Platform challenges
        TrapData(type: TrapType.fallingPlatform, position: const Vector2(2000, 0), size: const Vector2(100, 20)),
        TrapData(type: TrapType.crumblingPlatform, position: const Vector2(2200, 0), size: const Vector2(120, 20)),
        
        // Intense final section
        TrapData(type: TrapType.spike, position: const Vector2(2500, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.blade, position: const Vector2(2650, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.laser, position: const Vector2(2800, 40), size: const Vector2(100, 10)),
        TrapData(type: TrapType.fallingPlatform, position: const Vector2(3000, 0), size: const Vector2(100, 20)),
        TrapData(type: TrapType.spike, position: const Vector2(3200, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.blade, position: const Vector2(3400, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.crumblingPlatform, position: const Vector2(3600, 0), size: const Vector2(120, 20)),
        TrapData(type: TrapType.laser, position: const Vector2(3800, 30), size: const Vector2(100, 10)),
      ],
      powerUps: [
        // Strategic power-up placement
        PowerUpData(type: PowerUpType.shield, position: const Vector2(800, 50)),
        PowerUpData(type: PowerUpType.slowMotion, position: const Vector2(1600, 50)),
        PowerUpData(type: PowerUpType.shield, position: const Vector2(2400, 50)),
        PowerUpData(type: PowerUpType.slowMotion, position: const Vector2(3300, 50)),
      ],
    );
  }
  
  // Level 5: Extremely challenging with all trap types
  static LevelData _createLevel5() {
    return LevelData(
      levelNumber: 5,
      name: 'Ultimate Challenge',
      gameSpeed: 1.8,
      levelLength: 5000,
      traps: [
        // Intense opening
        TrapData(type: TrapType.spike, position: const Vector2(200, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.blade, position: const Vector2(350, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.spike, position: const Vector2(500, 0), size: const Vector2(50, 30)),
        
        // Complex platform section
        TrapData(type: TrapType.fallingPlatform, position: const Vector2(700, 0), size: const Vector2(100, 20)),
        TrapData(type: TrapType.crumblingPlatform, position: const Vector2(900, 0), size: const Vector2(120, 20)),
        TrapData(type: TrapType.laser, position: const Vector2(1100, 40), size: const Vector2(100, 10)),
        
        // Blade gauntlet
        TrapData(type: TrapType.blade, position: const Vector2(1300, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.blade, position: const Vector2(1450, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.blade, position: const Vector2(1600, 0), size: const Vector2(60, 60)),
        
        // Spike and laser combination
        TrapData(type: TrapType.spike, position: const Vector2(1800, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.laser, position: const Vector2(1900, 50), size: const Vector2(100, 10)),
        TrapData(type: TrapType.spike, position: const Vector2(2000, 0), size: const Vector2(50, 30)),
        
        // Platform challenge
        TrapData(type: TrapType.fallingPlatform, position: const Vector2(2200, 0), size: const Vector2(100, 20)),
        TrapData(type: TrapType.crumblingPlatform, position: const Vector2(2400, 0), size: const Vector2(120, 20)),
        TrapData(type: TrapType.fallingPlatform, position: const Vector2(2600, 0), size: const Vector2(100, 20)),
        
        // Extreme final section
        TrapData(type: TrapType.spike, position: const Vector2(2800, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.blade, position: const Vector2(2950, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.laser, position: const Vector2(3100, 30), size: const Vector2(100, 10)),
        TrapData(type: TrapType.spike, position: const Vector2(3250, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.crumblingPlatform, position: const Vector2(3400, 0), size: const Vector2(120, 20)),
        TrapData(type: TrapType.blade, position: const Vector2(3600, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.laser, position: const Vector2(3750, 40), size: const Vector2(100, 10)),
        TrapData(type: TrapType.fallingPlatform, position: const Vector2(3900, 0), size: const Vector2(100, 20)),
        TrapData(type: TrapType.spike, position: const Vector2(4100, 0), size: const Vector2(50, 30)),
        TrapData(type: TrapType.blade, position: const Vector2(4250, 0), size: const Vector2(60, 60)),
        TrapData(type: TrapType.laser, position: const Vector2(4400, 20), size: const Vector2(100, 10)),
        TrapData(type: TrapType.crumblingPlatform, position: const Vector2(4600, 0), size: const Vector2(120, 20)),
      ],
      powerUps: [
        // Strategic power-up placement
        PowerUpData(type: PowerUpType.shield, position: const Vector2(600, 50)),
        PowerUpData(type: PowerUpType.slowMotion, position: const Vector2(1200, 50)),
        PowerUpData(type: PowerUpType.shield, position: const Vector2(1700, 50)),
        PowerUpData(type: PowerUpType.slowMotion, position: const Vector2(2500, 50)),
        PowerUpData(type: PowerUpType.shield, position: const Vector2(3000, 50)),
        PowerUpData(type: PowerUpType.slowMotion, position: const Vector2(3500, 50)),
        PowerUpData(type: PowerUpType.shield, position: const Vector2(4000, 50)),
      ],
    );
  }
  
  // Procedural level generation for levels beyond 5
  static LevelData _createProceduralLevel(int levelNumber) {
    // Calculate game speed based on level number (capped at 3.0)
    double gameSpeed = 1.8 + (levelNumber - 5) * 0.1;
    if (gameSpeed > 3.0) gameSpeed = 3.0;
    
    // Calculate level length based on level number
    double levelLength = 5000 + (levelNumber - 5) * 200;
    if (levelLength > 8000) levelLength = 8000;
    
    // Generate traps
    List<TrapData> traps = [];
    List<PowerUpData> powerUps = [];
    
    // Number of obstacles increases with level
    int obstacleCount = 15 + (levelNumber - 5) * 2;
    if (obstacleCount > 30) obstacleCount = 30;
    
    // Number of power-ups
    int powerUpCount = 5 + (levelNumber - 5);
    if (powerUpCount > 10) powerUpCount = 10;
    
    // Generate obstacles with increasing density
    double spacing = levelLength / obstacleCount;
    for (int i = 0; i < obstacleCount; i++) {
      // Position with some randomness
      double position = 200 + i * spacing + (spacing * 0.2 * (i % 3 - 1));
      
      // Determine trap type based on position and level
      TrapType trapType;
      int typeSelector = (i + levelNumber) % 5;
      switch (typeSelector) {
        case 0:
          trapType = TrapType.spike;
          traps.add(TrapData(
            type: trapType,
            position: Vector2(position, 0),
            size: const Vector2(50, 30),
          ));
          break;
        case 1:
          trapType = TrapType.blade;
          traps.add(TrapData(
            type: trapType,
            position: Vector2(position, 0),
            size: const Vector2(60, 60),
          ));
          break;
        case 2:
          trapType = TrapType.laser;
          // Vary laser height
          double height = 20 + (i % 4) * 10;
          traps.add(TrapData(
            type: trapType,
            position: Vector2(position, height),
            size: const Vector2(100, 10),
          ));
          break;
        case 3:
          trapType = TrapType.fallingPlatform;
          traps.add(TrapData(
            type: trapType,
            position: Vector2(position, 0),
            size: const Vector2(100, 20),
          ));
          break;
        case 4:
          trapType = TrapType.crumblingPlatform;
          traps.add(TrapData(
            type: trapType,
            position: Vector2(position, 0),
            size: const Vector2(120, 20),
          ));
          break;
      }
      
      // Sometimes add a second trap to create more complex patterns
      if (levelNumber > 7 && i % 3 == 0) {
        double secondPosition = position + spacing * 0.3;
        TrapType secondType = TrapType.values[(typeSelector + 2) % 5];
        
        switch (secondType) {
          case TrapType.spike:
            traps.add(TrapData(
              type: secondType,
              position: Vector2(secondPosition, 0),
              size: const Vector2(50, 30),
            ));
            break;
          case TrapType.blade:
            traps.add(TrapData(
              type: secondType,
              position: Vector2(secondPosition, 0),
              size: const Vector2(60, 60),
            ));
            break;
          case TrapType.laser:
            double height = 30 + (i % 3) * 10;
            traps.add(TrapData(
              type: secondType,
              position: Vector2(secondPosition, height),
              size: const Vector2(100, 10),
            ));
            break;
          case TrapType.fallingPlatform:
            traps.add(TrapData(
              type: secondType,
              position: Vector2(secondPosition, 0),
              size: const Vector2(100, 20),
            ));
            break;
          case TrapType.crumblingPlatform:
            traps.add(TrapData(
              type: secondType,
              position: Vector2(secondPosition, 0),
              size: const Vector2(120, 20),
            ));
            break;
        }
      }
    }
    
    // Generate power-ups
    double powerUpSpacing = levelLength / powerUpCount;
    for (int i = 0; i < powerUpCount; i++) {
      // Position with some randomness
      double position = 400 + i * powerUpSpacing + (powerUpSpacing * 0.3 * (i % 3 - 1));
      
      // Alternate between shield and slow motion
      PowerUpType type = i % 2 == 0 ? PowerUpType.shield : PowerUpType.slowMotion;
      
      powerUps.add(PowerUpData(
        type: type,
        position: Vector2(position, 50),
      ));
    }
    
    return LevelData(
      levelNumber: levelNumber,
      name: 'Level $levelNumber',
      gameSpeed: gameSpeed,
      levelLength: levelLength,
      traps: traps,
      powerUps: powerUps,
    );
  }
}

class TrapData {
  final TrapType type;
  final Vector2 position;
  final Vector2 size;
  
  TrapData({
    required this.type,
    required this.position,
    required this.size,
  });
}

class PowerUpData {
  final PowerUpType type;
  final Vector2 position;
  
  PowerUpData({
    required this.type,
    required this.position,
  });
}

class Vector2 {
  final double x;
  final double y;
  
  const Vector2(this.x, this.y);
}
