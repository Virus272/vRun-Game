import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/game_controller.dart';
import '../core/enums.dart';
import '../widgets/custom_button.dart';

class MainMenuOverlay extends StatelessWidget {
  const MainMenuOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    final GameController gameController = Get.find<GameController>();
    
    return Container(
      color: Colors.black,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'vRun',
              style: TextStyle(
                color: Colors.white,
                fontSize: 64,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 80),
            CustomButton(
              text: 'play_game'.tr,
              onPressed: () {
                gameController.setGameState(GameState.playing);
              },
            ),
            const SizedBox(height: 20),
            CustomButton(
              text: 'select_level'.tr,
              onPressed: () {
                // Will be implemented in later steps
                // For now, just show a temporary message
                Get.snackbar(
                  'Coming Soon',
                  'Level selection will be available soon!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.grey[800],
                  colorText: Colors.white,
                );
              },
            ),
            const SizedBox(height: 20),
            CustomButton(
              text: 'settings'.tr,
              onPressed: () {
                // Will be implemented in later steps
                // For now, just show a temporary message
                Get.snackbar(
                  'Coming Soon',
                  'Settings will be available soon!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.grey[800],
                  colorText: Colors.white,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
