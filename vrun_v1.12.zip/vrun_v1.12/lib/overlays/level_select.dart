import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/game_controller.dart';
import '../widgets/custom_button.dart';

class LevelSelectOverlay extends StatelessWidget {
  const LevelSelectOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    final GameController gameController = Get.find<GameController>();
    
    return Container(
      color: Colors.black,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Row(
              children: [
                CustomButton(
                  text: 'back'.tr,
                  width: 100,
                  onPressed: () {
                    // Return to main menu
                    Get.back();
                  },
                ),
                const Spacer(),
                Text(
                  'select_level'.tr,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                const SizedBox(width: 100), // For symmetry
              ],
            ),
          ),
          const SizedBox(height: 20),
          Expanded(
            child: GridView.builder(
              padding: const EdgeInsets.all(20),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                childAspectRatio: 1,
                crossAxisSpacing: 15,
                mainAxisSpacing: 15,
              ),
              itemCount: 50, // 50 levels as specified in requirements
              itemBuilder: (context, index) {
                final levelNumber = index + 1;
                // For now, all levels are unlocked for development purposes
                const isUnlocked = true; // In the future, this will be based on player progress
                
                return GestureDetector(
                  onTap: () {
                    if (isUnlocked) {
                      gameController.setLevel(levelNumber);
                      // Will be implemented in later steps
                      Get.snackbar(
                        'Level Selected',
                        'Level $levelNumber selected!',
                        snackPosition: SnackPosition.BOTTOM,
                        backgroundColor: Colors.grey[800],
                        colorText: Colors.white,
                      );
                    }
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      color: isUnlocked ? Colors.white.withOpacity(0.1) : Colors.grey.withOpacity(0.05),
                      border: Border.all(
                        color: isUnlocked ? Colors.white : Colors.grey,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Text(
                        levelNumber.toString(),
                        style: const TextStyle(
                          color: isUnlocked ? Colors.white : Colors.grey,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
