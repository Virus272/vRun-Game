import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/game_controller.dart';
import '../widgets/custom_button.dart';

class VictoryOverlay extends StatelessWidget {
  const VictoryOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    final GameController gameController = Get.find<GameController>();
    
    return Container(
      color: Colors.black,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'level_complete'.tr,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 48,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 40),
            Text(
              '${'score'.tr}: ${gameController.score}',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
            const SizedBox(height: 60),
            CustomButton(
              text: 'next_level'.tr,
              onPressed: () {
                // Go to next level
                // Will be implemented in later steps
                Get.snackbar(
                  'Next Level',
                  'Going to next level!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.grey[800],
                  colorText: Colors.white,
                );
              },
            ),
            const SizedBox(height: 20),
            CustomButton(
              text: 'main_menu'.tr,
              onPressed: () {
                // Return to main menu
                // Will be implemented in later steps
                Get.snackbar(
                  'Main Menu',
                  'Returning to main menu!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.grey[800],
                  colorText: Colors.white,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
