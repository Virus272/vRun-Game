import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../widgets/custom_button.dart';

class PauseMenuOverlay extends StatelessWidget {
  const PauseMenuOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    
    return Container(
      color: Colors.black.withOpacity(0.8),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'pause'.tr,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 48,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 60),
            CustomButton(
              text: 'resume'.tr,
              onPressed: () {
                // Resume game
                // Will be implemented in later steps
                Get.snackbar(
                  'Resume',
                  'Game resumed!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.grey[800],
                  colorText: Colors.white,
                );
              },
            ),
            const SizedBox(height: 20),
            CustomButton(
              text: 'settings'.tr,
              onPressed: () {
                // Open settings menu
                // Will be implemented in later steps
                Get.snackbar(
                  'Settings',
                  'Settings will be available soon!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.grey[800],
                  colorText: Colors.white,
                );
              },
            ),
            const SizedBox(height: 20),
            CustomButton(
              text: 'main_menu'.tr,
              onPressed: () {
                // Return to main menu
                // Will be implemented in later steps
                Get.snackbar(
                  'Main Menu',
                  'Returning to main menu!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.grey[800],
                  colorText: Colors.white,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
