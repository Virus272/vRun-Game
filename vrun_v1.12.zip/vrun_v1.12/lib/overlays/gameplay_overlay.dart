import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/game_controller.dart';
import '../core/enums.dart';

class GameplayOverlay extends StatelessWidget {
  const GameplayOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    final GameController gameController = Get.find<GameController>();
    
    return Stack(
      children: [
        // Game UI elements
        Positioned(
          top: 20,
          left: 20,
          child: _buildScoreDisplay(gameController),
        ),
        Positioned(
          top: 20,
          right: 20,
          child: _buildPauseButton(),
        ),
        // Control buttons for manual mode
        Positioned(
          bottom: 20,
          left: 0,
          right: 0,
          child: Obx(() => gameController.controlMethod == ControlMethod.manual
              ? _buildManualControls()
              : const SizedBox.shrink()),
        ),
        // Power-up indicators
        Positioned(
          top: 70,
          left: 20,
          child: _buildPowerUpIndicators(gameController),
        ),
      ],
    );
  }

  Widget _buildScoreDisplay(GameController gameController) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.7),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.star,
            color: Colors.white,
            size: 24,
          ),
          const SizedBox(width: 8),
          Obx(() => Text(
                '${gameController.score}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              )),
        ],
      ),
    );
  }

  Widget _buildPauseButton() {
    return GestureDetector(
      onTap: () {
        // Show pause menu
        // Will be implemented in later steps
        Get.snackbar(
          'Pause',
          'Game paused!',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.grey[800],
          colorText: Colors.white,
        );
      },
      child: Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.7),
          borderRadius: BorderRadius.circular(8),
        ),
        child: const Icon(
          Icons.pause,
          color: Colors.white,
          size: 30,
        ),
      ),
    );
  }

  Widget _buildManualControls() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _buildControlButton(
          icon: Icons.arrow_back,
          onPressed: () {
            // Move left
            // Will be implemented in later steps
          },
        ),
        const SizedBox(width: 20),
        _buildControlButton(
          icon: Icons.arrow_upward,
          onPressed: () {
            // Jump
            // Will be implemented in later steps
          },
        ),
        const SizedBox(width: 20),
        _buildControlButton(
          icon: Icons.arrow_downward,
          onPressed: () {
            // Bow
            // Will be implemented in later steps
          },
        ),
        const SizedBox(width: 20),
        _buildControlButton(
          icon: Icons.arrow_forward,
          onPressed: () {
            // Move right
            // Will be implemented in later steps
          },
        ),
      ],
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required VoidCallback onPressed,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.3),
          borderRadius: BorderRadius.circular(30),
        ),
        child: Icon(
          icon,
          color: Colors.white,
          size: 30,
        ),
      ),
    );
  }

  Widget _buildPowerUpIndicators(GameController gameController) {
    return Row(
      children: [
        // Shield indicator
        Obx(() => gameController.hasShield
            ? Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.shield,
                  color: Colors.white,
                  size: 24,
                ),
              )
            : const SizedBox.shrink()),
        const SizedBox(width: 10),
        // Slow motion indicator
        Obx(() => gameController.hasSlowMotion
            ? Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.purple.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.slow_motion_video,
                  color: Colors.white,
                  size: 24,
                ),
              )
            : const SizedBox.shrink()),
      ],
    );
  }
}
