import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/game_controller.dart';
import '../widgets/custom_button.dart';

class GameOverOverlay extends StatelessWidget {
  const GameOverOverlay({super.key});

  @override
  Widget build(BuildContext context) {
    final GameController gameController = Get.find<GameController>();
    
    // Random death message
    final List<String> deathMessages = [
      'death_msg_1'.tr,
      'death_msg_2'.tr,
      'death_msg_3'.tr,
      'death_msg_4'.tr,
      'death_msg_5'.tr,
    ];
    final String randomMessage = deathMessages[DateTime.now().millisecond % deathMessages.length];
    
    return Container(
      color: Colors.black,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'game_over'.tr,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 48,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              randomMessage,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontStyle: FontStyle.italic,
              ),
            ),
            const SizedBox(height: 40),
            Text(
              '${'your_score'.tr}: ${gameController.score}',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
              ),
            ),
            const SizedBox(height: 60),
            CustomButton(
              text: 'try_again'.tr,
              onPressed: () {
                // Retry level
                // Will be implemented in later steps
                Get.snackbar(
                  'Retry',
                  'Retrying level!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.grey[800],
                  colorText: Colors.white,
                );
              },
            ),
            const SizedBox(height: 20),
            CustomButton(
              text: 'main_menu'.tr,
              onPressed: () {
                // Return to main menu
                // Will be implemented in later steps
                Get.snackbar(
                  'Main Menu',
                  'Returning to main menu!',
                  snackPosition: SnackPosition.BOTTOM,
                  backgroundColor: Colors.grey[800],
                  colorText: Colors.white,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
