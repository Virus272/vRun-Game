import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/settings_controller.dart';
import '../controllers/localization_controller.dart';
import '../widgets/custom_button.dart';

class SettingsMenu extends StatelessWidget {
  final SettingsController settingsController = Get.find<SettingsController>();
  final LocalizationController localizationController = Get.find<LocalizationController>();

  SettingsMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(0.8),
      child: Center(
        child: Container(
          width: 300,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: const Offset(0, 3),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'settings'.tr,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              const SizedBox(height: 20),
              
              // Language selection
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'language'.tr,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.black,
                    ),
                  ),
                  Obx(() => DropdownButton<String>(
                    value: localizationController.currentLanguage,
                    onChanged: (String? newValue) {
                      if (newValue != null) {
                        localizationController.changeLanguage(newValue);
                      }
                    },
                    items: const [
                      DropdownMenuItem<String>(
                        value: 'en',
                        child: Text('English'),
                      ),
                      DropdownMenuItem<String>(
                        value: 'ar',
                        child: Text('العربية'),
                      ),
                    ],
                  )),
                ],
              ),
              const SizedBox(height: 10),
              
              // Control method selection
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'control_method'.tr,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.black,
                    ),
                  ),
                  Obx(() => DropdownButton<String>(
                    value: settingsController.controlMethod.value == 'auto' ? 'auto' : 'manual',
                    onChanged: (String? newValue) {
                      if (newValue != null) {
                        settingsController.setControlMethod(newValue);
                      }
                    },
                    items: [
                      DropdownMenuItem<String>(
                        value: 'auto',
                        child: Text('auto_run'.tr),
                      ),
                      DropdownMenuItem<String>(
                        value: 'manual',
                        child: Text('manual'.tr),
                      ),
                    ],
                  )),
                ],
              ),
              const SizedBox(height: 10),
              
              // Sound toggle
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'sound'.tr,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.black,
                    ),
                  ),
                  Obx(() => Switch(
                    value: settingsController.soundEnabled.value,
                    onChanged: (bool value) {
                      settingsController.setSoundEnabled(value);
                    },
                    activeColor: Colors.black,
                  )),
                ],
              ),
              const SizedBox(height: 10),
              
              // Music toggle
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'music'.tr,
                    style: const TextStyle(
                      fontSize: 18,
                      color: Colors.black,
                    ),
                  ),
                  Obx(() => Switch(
                    value: settingsController.musicEnabled.value,
                    onChanged: (bool value) {
                      settingsController.setMusicEnabled(value);
                    },
                    activeColor: Colors.black,
                  )),
                ],
              ),
              const SizedBox(height: 10),
              
              // Sound volume slider
              Obx(() => settingsController.soundEnabled.value
                ? Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'sound_volume'.tr,
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.black,
                            ),
                          ),
                          Text(
                            '${(settingsController.sfxVolume.value * 100).toInt()}%',
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                      Slider(
                        value: settingsController.sfxVolume.value,
                        onChanged: (double value) {
                          settingsController.setSfxVolume(value);
                        },
                        activeColor: Colors.black,
                        inactiveColor: Colors.grey,
                      ),
                    ],
                  )
                : const SizedBox.shrink()
              ),
              
              // Music volume slider
              Obx(() => settingsController.musicEnabled.value
                ? Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'music_volume'.tr,
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.black,
                            ),
                          ),
                          Text(
                            '${(settingsController.musicVolume.value * 100).toInt()}%',
                            style: const TextStyle(
                              fontSize: 18,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                      Slider(
                        value: settingsController.musicVolume.value,
                        onChanged: (double value) {
                          settingsController.setMusicVolume(value);
                        },
                        activeColor: Colors.black,
                        inactiveColor: Colors.grey,
                      ),
                    ],
                  )
                : const SizedBox.shrink()
              ),
              
              const SizedBox(height: 20),
              
              // Back button
              CustomButton(
                text: 'back'.tr,
                onPressed: () {
                  Get.back();
                },
                width: 200,
                height: 50,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
