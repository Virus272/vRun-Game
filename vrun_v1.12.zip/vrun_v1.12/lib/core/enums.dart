enum PlayerState {
  idle,
  running,
  jumping,
  doubleJumping,
  bowing,
  dying
}

enum ControlMethod {
  auto,
  manual
}

enum PowerUpType {
  shield,
  slowMotion
}

enum TrapType {
  spike,
  blade,
  laser,
  crumblingPlatform,
  fallingPlatform
}

enum GameState {
  loading,
  menu,
  playing,
  paused,
  gameOver,
  victory
}
