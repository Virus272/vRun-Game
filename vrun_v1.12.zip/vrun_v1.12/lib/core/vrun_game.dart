import 'package:flame/game.dart';
import 'package:flame/components.dart'; // Required for CameraComponent, World, etc.
import 'package:flame/input.dart';
import 'package:flame/collisions.dart';
import 'package:get/get.dart';
import '../controllers/game_controller.dart';
import '../controllers/settings_controller.dart';
import '../core/constants.dart';
import '../core/enums.dart';
import '../entities/player.dart';
import '../entities/trap.dart';
import '../entities/powerup.dart';
import '../services/audio_manager.dart';
import '../entities/parallax_background.dart';
import '../entities/particle_effects.dart';
import '../levels/level_data.dart' hide Vector2; // Hide Vector2 from level_data

class VRunGame extends FlameGame 
    with HasCollisionDetection, KeyboardEvents, TapDetector, DoubleTapDetector {
  
  // Controllers
  final GameController gameController = Get.find<GameController>();
  final SettingsController settingsController = Get.find<SettingsController>();

  // Audio manager
  final AudioManager _audioManager = AudioManager();

  // Game speed
  double _gameSpeed = GameConstants.initialGameSpeed;
  double get gameSpeed => _gameSpeed * (gameController.hasSlowMotion ? 0.5 : 1.0);

  // Player reference
  late Player player;

  // World and Camera
  late final CameraComponent cameraComponent;
  late final World world;

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    // Initialize audio
    await _audioManager.initialize();

    // Initialize World and CameraComponent
    world = World();
    cameraComponent = CameraComponent.withFixedResolution(
      world: world,
      width: GameConstants.gameWidth,
      height: GameConstants.gameHeight,
    );
    cameraComponent.viewfinder.anchor = Anchor.topLeft;
    // Add CameraComponent and World to the game
    addAll([cameraComponent, world]);

    // Add parallax background to the world
    world.add(ParallaxBackground());

    // Initialize player and add to the world
    player = Player(
      position: Vector2(100, GameConstants.gameHeight - 50), // Position relative to world/screen size
      size: Vector2(50, 80),
    );
    world.add(player);

    // Listen for game state changes from the controller
    ever(gameController.gameStateObs, _onGameStateChanged);

    // Initial overlay update based on controller state
    _updateOverlays(gameController.gameState);

    // Play background music if enabled
    if (settingsController.musicEnabled.value) {
      _audioManager.playBackgroundMusic();
    }

    // Load initial level
    setLevel(gameController.currentLevel);
  }

  @override
  void update(double dt) {
    final effectiveDt =
        gameController.gameState == GameState.playing ? dt * gameSpeed : dt;
    // Update the world and its components
    world.update(effectiveDt);
    // Update the camera (if needed, e.g., following the player)
    // cameraComponent.update(effectiveDt); // Usually handled automatically
    super.update(effectiveDt); // Update other game-level aspects if any
  }

  void _onGameStateChanged(GameState state) {
    switch (state) {
      case GameState.playing:
        if (settingsController.musicEnabled.value) _audioManager.resumeBackgroundMusic();
        break;
      case GameState.paused:
        _audioManager.pauseBackgroundMusic();
        break;
      case GameState.gameOver:
        _audioManager.playDeathSound();
        _audioManager.stopBackgroundMusic();
        if (player.isMounted) {
          // Add particle effects to the world
          world.add(ParticleEffects.createDeathEffect(
              player.absolutePosition, player.size));
        }
        break;
      case GameState.victory:
        _audioManager.playVictorySound();
        _audioManager.stopBackgroundMusic();
        if (player.isMounted) {
          // Add particle effects to the world
          world.add(ParticleEffects.createVictoryEffect(player.absolutePosition));
        }
        break;
      default:
        break;
    }
    _updateOverlays(state);
  }

  void _updateOverlays(GameState state) {
    overlays.removeAll(overlays.activeOverlays.toList());
    switch (state) {
      case GameState.loading: overlays.add("splash"); break;
      case GameState.menu: overlays.add("main_menu"); break;
      case GameState.playing: overlays.add("gameplay"); break;
      case GameState.paused: 
        overlays.add("gameplay"); 
        overlays.add("pause"); 
        break;
      case GameState.gameOver: overlays.add("game_over"); break;
      case GameState.victory: overlays.add("victory"); break;
    }
  }

  void setGameState(GameState state) {
    gameController.setGameState(state);
  }

  void setLevel(int level) {
    gameController.setLevel(level);
    _gameSpeed = GameConstants.initialGameSpeed +
        (level - 1) * GameConstants.speedIncreasePerLevel;
    _gameSpeed = _gameSpeed.clamp(0.0, GameConstants.maxGameSpeed);
    _loadLevelVisuals(level);
  }

  void _loadLevelVisuals(int level) {
    // Clear existing traps and power-ups from the world
    world.children.whereType<Trap>().forEach((trap) => trap.removeFromParent());
    world.children.whereType<PowerUp>().forEach((powerUp) => powerUp.removeFromParent());

    // Reset player state and position
    // Use gameHeight from constants for positioning
    player.position = Vector2(100, GameConstants.gameHeight - 50); 
    player.resetState();

    final levelData = LevelData.createLevel(level);
    _gameSpeed = levelData.gameSpeed.clamp(0.0, GameConstants.maxGameSpeed);

    // Add traps to the world
    for (final trapData in levelData.traps) {
      world.add(Trap(
        type: trapData.type,
        position: Vector2(trapData.position.x, trapData.position.y),
        size: Vector2(trapData.size.x, trapData.size.y),
      ));
    }

    // Add power-ups to the world
    for (final powerUpData in levelData.powerUps) {
      world.add(PowerUp(
        type: powerUpData.type,
        position: Vector2(powerUpData.position.x, powerUpData.position.y),
        size: Vector2(40, 40),
      ));
    }

    if (settingsController.musicEnabled.value) {
      _audioManager.playBackgroundMusic();
    }
  }

  @override
  void onTap() {
    super.onTap();
    if (gameController.gameState == GameState.playing &&
        gameController.controlMethod == ControlMethod.auto) {
      player.jump();
      _audioManager.playJumpSound();
      if (player.isMounted) {
        // Add particle effects to the world
        world.add(ParticleEffects.createJumpEffect(
            player.absolutePosition + Vector2(0, player.size.y / 2)));
      }
    }
  }

  @override
  void onDoubleTap() {
    super.onDoubleTap();
    if (gameController.gameState == GameState.playing &&
        gameController.controlMethod == ControlMethod.auto) {
      player.jump();
      _audioManager.playJumpSound();
    }
  }

  void resetGame() {
    gameController.setScore(0);
    gameController.setShield(false);
    gameController.setSlowMotion(false);
    setGameState(GameState.playing);
    _loadLevelVisuals(gameController.currentLevel);
  }

  void pauseGame() {
    if (gameController.gameState == GameState.playing) {
      setGameState(GameState.paused);
      pauseEngine();
    }
  }

  void resumeGame() {
    if (gameController.gameState == GameState.paused) {
      setGameState(GameState.playing);
      resumeEngine();
    }
  }
}

