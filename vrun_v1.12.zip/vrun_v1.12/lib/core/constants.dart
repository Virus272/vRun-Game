class GameConstants {
  // Game dimensions
  static const double gameWidth = 1080;
  static const double gameHeight = 1920;
  
  // Player constants
  static const double playerSpeed = 300;
  static const double jumpForce = 600;
  static const double doubleJumpForce = 500;
  static const double gravity = 1200;
  
  // Game settings
  static const double initialGameSpeed = 1.0;
  static const double speedIncreasePerLevel = 0.1;
  static const double maxGameSpeed = 2.5;
  
  // Power-up durations (in seconds)
  static const double shieldDuration = 10.0;
  static const double slowMotionDuration = 5.0;
  static const double slowMotionFactor = 0.5;
}

class AssetPaths {
  // Audio paths
  static const String jumpSound = 'audio/jump.mp3';
  static const String landSound = 'audio/land.mp3';
  static const String bowSound = 'audio/bow.mp3';
  static const String shieldSound = 'audio/shield.mp3';
  static const String slowMotionSound = 'audio/slow_motion.mp3';
  static const String deathSound = 'audio/death.mp3';
  static const String backgroundMusic = 'audio/background_music.mp3';
  
  // Image paths
  static const String playerIdlePrefix = 'images/player/idle/idle_';
  static const String playerRunPrefix = 'images/player/run/run_';
  static const String playerJumpPrefix = 'images/player/jump/jump_';
  static const String playerBowPrefix = 'images/player/bow/bow_';
  static const String playerDeathPrefix = 'images/player/death/death_';
  
  // Trap paths
  static const String spikesPrefix = 'images/traps/spikes/spikes_';
  static const String bladesPrefix = 'images/traps/blades/blades_';
  static const String lasersPrefix = 'images/traps/lasers/lasers_';
  static const String platformsPrefix = 'images/traps/crumbling_platforms/platform_';
  
  // Power-up paths
  static const String shieldPowerup = 'images/powerups/shield.png';
  static const String slowMotionPowerup = 'images/powerups/slow_motion.png';
  
  // Background paths
  static const String parallaxLayer1 = 'images/backgrounds/parallax_layer1.png';
  static const String parallaxLayer2 = 'images/backgrounds/parallax_layer2.png';
  static const String parallaxLayer3 = 'images/backgrounds/parallax_layer3.png';
  static const String parallaxConfig = 'images/backgrounds/parallax.json';
  
  // Localization paths
  static const String enLocalization = 'assets/localization/en.json';
  static const String arLocalization = 'assets/localization/ar.json';
}

class StorageKeys {
  static const String languageKey = 'language';
  static const String controlMethodKey = 'control_method';
  static const String highScoreKey = 'high_score';
  static const String lastLevelKey = 'last_level';
  static const String soundEnabledKey = 'sound_enabled';
  static const String musicEnabledKey = 'music_enabled';
}
