import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/constants.dart';

class LocalizationService extends Translations {
  // Default locale
  static const locale = Locale('en');
  
  // Fallback locale
  static const fallbackLocale = Locale('en');
  
  // Supported languages
  static final languages = [
    'English',
    'العربية',
  ];
  
  // Supported locales
  static final locales = [
    const Locale('en'),
    const Locale('ar'),
  ];
  
  // Language codes
  static final languageCodes = [
    'en',
    'ar',
  ];
  
  // Locale keys
  static Map<String, Map<String, String>> _localizationKeys = {};
  
  // Initialize
  static Future<void> init() async {
    // Load English translations
    String enJson = await rootBundle.loadString('assets/localization/en.json');
    Map<String, dynamic> enMap = json.decode(enJson);
    Map<String, String> enStrings = {};
    enMap.forEach((key, value) {
      enStrings[key] = value.toString();
    });
    
    // Load Arabic translations
    String arJson = await rootBundle.loadString('assets/localization/ar.json');
    Map<String, dynamic> arMap = json.decode(arJson);
    Map<String, String> arStrings = {};
    arMap.forEach((key, value) {
      arStrings[key] = value.toString();
    });
    
    // Set localization keys
    _localizationKeys = {
      'en': enStrings,
      'ar': arStrings,
    };
  }
  
  // Get locale from language
  static Locale getLocaleFromLanguage(String language) {
    for (int i = 0; i < languages.length; i++) {
      if (languages[i] == language) {
        return locales[i];
      }
    }
    return locale;
  }
  
  // Get language from locale
  static String getLanguageFromLocale(Locale locale) {
    for (int i = 0; i < locales.length; i++) {
      if (locales[i].languageCode == locale.languageCode) {
        return languages[i];
      }
    }
    return languages[0];
  }
  
  // Get language code from language
  static String getLanguageCodeFromLanguage(String language) {
    for (int i = 0; i < languages.length; i++) {
      if (languages[i] == language) {
        return languageCodes[i];
      }
    }
    return languageCodes[0];
  }
  
  // Change locale
  static void changeLocale(String languageCode) {
    final locale = Locale(languageCode);
    Get.updateLocale(locale);
    
    // Save to preferences
    saveLocale(languageCode);
  }
  
  // Save locale
  static Future<void> saveLocale(String languageCode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(StorageKeys.languageKey, languageCode);
  }
  
  // Load saved locale
  static Future<Locale> loadSavedLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final languageCode = prefs.getString(StorageKeys.languageKey);
    
    if (languageCode != null) {
      return Locale(languageCode);
    }
    
    return locale;
  }
  
  // Keys and translations
  @override
  Map<String, Map<String, String>> get keys => _localizationKeys;
}
