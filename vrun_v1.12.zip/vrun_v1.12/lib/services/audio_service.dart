import 'package:flame_audio/flame_audio.dart';
import 'package:get/get.dart';
import '../controllers/settings_controller.dart';
import '../core/constants.dart';

class AudioService extends GetxService {
  // Settings controller
  final SettingsController _settingsController = Get.find<SettingsController>();
  
  // Audio cache
  bool _initialized = false;
  
  Future<AudioService> init() async {
    // Preload audio files
    await _preloadAudio();
    _initialized = true;
    return this;
  }
  
  Future<void> _preloadAudio() async {
    // Preload sound effects
    await FlameAudio.audioCache.loadAll([
      AssetPaths.jumpSound,
      AssetPaths.landSound,
      AssetPaths.bowSound,
      AssetPaths.shieldSound,
      AssetPaths.slowMotionSound,
      AssetPaths.deathSound,
    ]);
    
    // Preload background music
    await FlameAudio.audioCache.load(AssetPaths.backgroundMusic);
  }
  
  // Play sound effect
  void playSfx(String sound) {
    if (_initialized && _settingsController.soundEnabled.value) {
      FlameAudio.play(sound);
    }
  }
  
  // Play jump sound
  void playJumpSound() {
    playSfx(AssetPaths.jumpSound);
  }
  
  // Play land sound
  void playLandSound() {
    playSfx(AssetPaths.landSound);
  }
  
  // Play bow sound
  void playBowSound() {
    playSfx(AssetPaths.bowSound);
  }
  
  // Play shield sound
  void playShieldSound() {
    playSfx(AssetPaths.shieldSound);
  }
  
  // Play slow motion sound
  void playSlowMotionSound() {
    playSfx(AssetPaths.slowMotionSound);
  }
  
  // Play death sound
  void playDeathSound() {
    playSfx(AssetPaths.deathSound);
  }
  
  // Play background music
  void playBackgroundMusic() {
    if (_initialized && _settingsController.musicEnabled.value) {
      FlameAudio.bgm.play(AssetPaths.backgroundMusic);
    }
  }
  
  // Stop background music
  void stopBackgroundMusic() {
    if (_initialized) {
      FlameAudio.bgm.stop();
    }
  }
  
  // Pause background music
  void pauseBackgroundMusic() {
    if (_initialized) {
      FlameAudio.bgm.pause();
    }
  }
  
  // Resume background music
  void resumeBackgroundMusic() {
    if (_initialized && _settingsController.musicEnabled.value) {
      FlameAudio.bgm.resume();
    }
  }
}
