import 'package:flame_audio/flame_audio.dart';
import 'package:get/get.dart';
import '../controllers/settings_controller.dart';

class AudioManager {
  // Singleton instance
  static final AudioManager _instance = AudioManager._internal();
  factory AudioManager() => _instance;
  AudioManager._internal();
  
  // Settings controller for volume settings
  final SettingsController _settingsController = Get.find<SettingsController>();
  
  // Audio files
  static const String _jumpSfx = 'sfx/jump.mp3';
  static const String _doubleJumpSfx = 'sfx/double_jump.mp3';
  static const String _bowSfx = 'sfx/bow.mp3';
  static const String _collisionSfx = 'sfx/collision.mp3';
  static const String _deathSfx = 'sfx/death.mp3';
  static const String _powerUpSfx = 'sfx/powerup.mp3';
  static const String _victorySfx = 'sfx/victory.mp3';
  static const String _backgroundMusic = 'music/background.mp3';
  
  // Initialize audio
  Future<void> initialize() async {
    // Preload all sound effects
    await FlameAudio.audioCache.loadAll([
      _jumpSfx,
      _doubleJumpSfx,
      _bowSfx,
      _collisionSfx,
      _deathSfx,
      _powerUpSfx,
      _victorySfx,
    ]);
    
    // Set initial volumes
    FlameAudio.bgm.audioPlayer.setVolume(_settingsController.musicVolume.value);
  }
  
  // Play jump sound
  void playJumpSound() {
    if (_settingsController.soundEnabled.value) {
      FlameAudio.play(_jumpSfx, volume: _settingsController.sfxVolume.value);
    }
  }
  
  // Play double jump sound
  void playDoubleJumpSound() {
    if (_settingsController.soundEnabled.value) {
      FlameAudio.play(_doubleJumpSfx, volume: _settingsController.sfxVolume.value);
    }
  }
  
  // Play bow sound
  void playBowSound() {
    if (_settingsController.soundEnabled.value) {
      FlameAudio.play(_bowSfx, volume: _settingsController.sfxVolume.value);
    }
  }
  
  // Play collision sound
  void playCollisionSound() {
    if (_settingsController.soundEnabled.value) {
      FlameAudio.play(_collisionSfx, volume: _settingsController.sfxVolume.value);
    }
  }
  
  // Play death sound
  void playDeathSound() {
    if (_settingsController.soundEnabled.value) {
      FlameAudio.play(_deathSfx, volume: _settingsController.sfxVolume.value);
    }
  }
  
  // Play power-up sound
  void playPowerUpSound() {
    if (_settingsController.soundEnabled.value) {
      FlameAudio.play(_powerUpSfx, volume: _settingsController.sfxVolume.value);
    }
  }
  
  // Play victory sound
  void playVictorySound() {
    if (_settingsController.soundEnabled.value) {
      FlameAudio.play(_victorySfx, volume: _settingsController.sfxVolume.value);
    }
  }
  
  // Play background music
  void playBackgroundMusic() {
    if (_settingsController.musicEnabled.value) {
      FlameAudio.bgm.play(_backgroundMusic, volume: _settingsController.musicVolume.value);
    }
  }
  
  // Stop background music
  void stopBackgroundMusic() {
    FlameAudio.bgm.stop();
  }
  
  // Pause background music
  void pauseBackgroundMusic() {
    FlameAudio.bgm.pause();
  }
  
  // Resume background music
  void resumeBackgroundMusic() {
    if (_settingsController.musicEnabled.value) {
      FlameAudio.bgm.resume();
    }
  }
  
  // Update music volume
  void updateMusicVolume(double volume) {
    FlameAudio.bgm.audioPlayer.setVolume(volume);
  }
  
  // Generate placeholder audio files for testing
  static Future<void> generatePlaceholderAudio() async {
    // This would be implemented in a real project to create placeholder audio files
    // For this demo, we'll assume the audio files exist
  }
}
