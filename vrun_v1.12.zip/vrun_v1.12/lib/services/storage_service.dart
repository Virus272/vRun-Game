import 'package:shared_preferences/shared_preferences.dart';
import 'package:get/get.dart';
import '../core/constants.dart';
import '../core/enums.dart';

class StorageService extends GetxService {
  late SharedPreferences _prefs;
  
  Future<StorageService> init() async {
    _prefs = await SharedPreferences.getInstance();
    return this;
  }
  
  // Language methods
  Future<String?> getLanguage() async {
    return _prefs.getString(StorageKeys.languageKey);
  }
  
  Future<bool> setLanguage(String language) async {
    return await _prefs.setString(StorageKeys.languageKey, language);
  }
  
  // Control method methods
  Future<ControlMethod> getControlMethod() async {
    final int? value = _prefs.getInt(StorageKeys.controlMethodKey);
    return value == null 
        ? ControlMethod.auto 
        : ControlMethod.values[value];
  }
  
  Future<bool> setControlMethod(ControlMethod method) async {
    return await _prefs.setInt(StorageKeys.controlMethodKey, method.index);
  }
  
  // High score methods
  Future<int> getHighScore() async {
    return _prefs.getInt(StorageKeys.highScoreKey) ?? 0;
  }
  
  Future<bool> setHighScore(int score) async {
    return await _prefs.setInt(StorageKeys.highScoreKey, score);
  }
  
  // Last level methods
  Future<int> getLastLevel() async {
    return _prefs.getInt(StorageKeys.lastLevelKey) ?? 1;
  }
  
  Future<bool> setLastLevel(int level) async {
    return await _prefs.setInt(StorageKeys.lastLevelKey, level);
  }
  
  // Sound settings methods
  Future<bool> getSoundEnabled() async {
    return _prefs.getBool(StorageKeys.soundEnabledKey) ?? true;
  }
  
  Future<bool> setSoundEnabled(bool enabled) async {
    return await _prefs.setBool(StorageKeys.soundEnabledKey, enabled);
  }
  
  // Music settings methods
  Future<bool> getMusicEnabled() async {
    return _prefs.getBool(StorageKeys.musicEnabledKey) ?? true;
  }
  
  Future<bool> setMusicEnabled(bool enabled) async {
    return await _prefs.setBool(StorageKeys.musicEnabledKey, enabled);
  }
}
