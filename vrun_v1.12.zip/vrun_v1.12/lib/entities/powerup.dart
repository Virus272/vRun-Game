import 'dart:math'; // Import dart:math for sin function
import 'package:flame/components.dart';
import 'package:flame/collisions.dart';
import 'package:flame/effects.dart'; // Import for effects
import 'package:flutter/material.dart';
import '../core/enums.dart';
import 'powerup_sprites.dart';
import 'player.dart'; // Import Player to check type during collision

class PowerUp extends PositionComponent with CollisionCallbacks, HasGameRef {
  // Power-up type
  final PowerUpType type;

  // Is power-up collected
  bool _isCollected = false;
  bool get isCollected => _isCollected;

  // Animation data
  late final List<Path> _animationFrames;
  int _currentFrame = 0;
  double _animTimer = 0;
  final double _frameDuration = 0.3;

  // Floating animation
  double _baseY;
  double _floatTimer = 0;
  final double _floatSpeed = 1.5;
  final double _floatAmplitude = 5.0; // Pixels to float up/down

  // Constructor
  PowerUp({
    required this.type,
    required Vector2 position,
    required Vector2 size,
  }) : _baseY = position.y, // Store initial Y position
       super(
          position: position,
          size: size,
          anchor: Anchor.center,
        );

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    // Add hitbox for collision detection
    add(CircleHitbox()); // Use default hitbox covering the component size

    // Load animation frames based on power-up type
    _loadAnimationFrames();
  }

  void _loadAnimationFrames() {
    switch (type) {
      case PowerUpType.shield:
        _animationFrames = PowerUpSprites.createShieldFrames();
        break;
      case PowerUpType.slowMotion:
        _animationFrames = PowerUpSprites.createSlowMotionFrames();
        break;
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas); // Important for effects
    // Custom rendering based on power-up type
    if (_animationFrames.isEmpty || _isCollected) return; // Don't render if collected

    Path currentPath = _animationFrames[_currentFrame];

    // Scale the path to match component size
    // Assuming original vector art is designed for 50x50
    final Matrix4 matrix = Matrix4.identity()
      ..scale(size.x / 50, size.y / 50); // Scale to fit component size

    final Path scaledPath = currentPath.transform(matrix.storage);

    // Draw the power-up centered (due to Anchor.center)
    final Paint paint = Paint()
      ..color = type == PowerUpType.shield ? Colors.blue : Colors.purple;

    // Apply offset for centering if needed, though Anchor.center should handle it.
    // If Anchor.center isn't working as expected with custom paint, manual offset might be needed.
    // Example: canvas.translate(-size.x / 2, -size.y / 2);

    PowerUpSprites.drawPowerUpToCanvas(canvas, scaledPath, paint.color);
  }

  @override
  void update(double dt) {
    super.update(dt);

    if (_isCollected) return; // Stop updates if collected

    // Update animation
    _updateAnimation(dt);

    // Floating animation
    _updateFloatingAnimation(dt);

    // Rotation for slow motion power-up
    if (type == PowerUpType.slowMotion) {
      angle += dt * 0.5; // Slower rotation
    }
  }

  void _updateAnimation(double dt) {
    _animTimer += dt;

    if (_animTimer >= _frameDuration) {
      _animTimer = 0;
      _currentFrame = (_currentFrame + 1) % _animationFrames.length;
    }
  }

  void _updateFloatingAnimation(double dt) {
    // Simple sine wave floating effect around the base Y position
    _floatTimer += dt * _floatSpeed;
    position.y = _baseY + sin(_floatTimer) * _floatAmplitude;
  }

  // Handle collision
  @override
  void onCollisionStart(
    Set<Vector2> intersectionPoints,
    PositionComponent other,
  ) {
    super.onCollisionStart(intersectionPoints, other);
    if (!_isCollected && other is Player) {
      collect(other); // Pass the player reference
    }
  }

  // Collect power-up
  void collect(Player player) {
    if (_isCollected) return;
    _isCollected = true;

    // Apply effect to player
    applyEffect(player);

    // Visual effect before removing: scale up and fade out
    add(
      ScaleEffect.to(
        Vector2.all(1.5),
        EffectController(duration: 0.3),
        onComplete: () {
          // After scaling, fade out
          add(
            OpacityEffect.fadeOut(
              EffectController(duration: 0.2),
              onComplete: () => removeFromParent(), // Remove after fading
            ),
          );
        },
      ),
    );

    // Stop hitbox detection immediately
    final hitbox = children.whereType<CircleHitbox>().firstOrNull;
    if (hitbox != null) {
        remove(hitbox);
    }

    // TODO: Add collection sound effect
  }

  // Apply power-up effect to player
  void applyEffect(Player player) {
    switch (type) {
      case PowerUpType.shield:
        player.collectShield();
        break;
      case PowerUpType.slowMotion:
        player.collectSlowMotion();
        break;
    }
  }
}

