import 'package:flame/components.dart';
import 'package:flame/collisions.dart';
import 'package:flutter/material.dart';
import '../core/constants.dart';
import '../core/enums.dart';
import 'trap_sprites.dart';

class Trap extends PositionComponent with CollisionCallbacks, HasGameRef {
  // Trap type
  final TrapType type;
  
  // Is trap active
  bool _isActive = true;
  bool get isActive => _isActive;
  
  // Animation data
  late final List<Path> _animationFrames;
  int _currentFrame = 0;
  double _animTimer = 0;
  double _frameDuration = 0.2;
  
  // Special trap properties
  bool _isFalling = false;
  double _fallSpeed = 0;
  bool _isCrumbling = false;
  double _crumbleTimer = 0;
  
  // Constructor
  Trap({
    required this.type,
    required Vector2 position,
    required Vector2 size,
  }) : super(
    position: position,
    size: size,
    anchor: Anchor.bottomCenter,
  );
  
  @override
  Future<void> onLoad() async {
    await super.onLoad();
    
    // Add hitbox for collision detection
    add(RectangleHitbox(
      size: Vector2(size.x * 0.8, size.y * 0.8),
      position: Vector2(size.x * 0.1, size.y * 0.1),
    ));
    
    // Load animation frames based on trap type
    _loadAnimationFrames();
    
    // Set frame duration based on trap type
    _setFrameDuration();
  }
  
  void _loadAnimationFrames() {
    switch (type) {
      case TrapType.spike:
        _animationFrames = [TrapSprites.createSpikeTrap()];
        break;
      case TrapType.blade:
        _animationFrames = TrapSprites.createBladeFrames();
        break;
      case TrapType.laser:
        _animationFrames = TrapSprites.createLaserFrames();
        break;
      case TrapType.fallingPlatform:
        _animationFrames = TrapSprites.createFallingPlatformFrames();
        break;
      case TrapType.crumblingPlatform:
        _animationFrames = TrapSprites.createCrumblingPlatformFrames();
        break;
    }
  }
  
  void _setFrameDuration() {
    switch (type) {
      case TrapType.spike:
        _frameDuration = 1.0; // Static, no animation
        break;
      case TrapType.blade:
        _frameDuration = 0.1; // Fast rotation
        break;
      case TrapType.laser:
        _frameDuration = 0.3; // Medium pulse rate
        break;
      case TrapType.fallingPlatform:
        _frameDuration = 0.2; // Medium fall rate
        break;
      case TrapType.crumblingPlatform:
        _frameDuration = 0.2; // Medium crumble rate
        break;
    }
  }
  
  @override
  void render(Canvas canvas) {
    // Custom rendering based on trap type
    if (_animationFrames.isEmpty) return;
    
    Path currentPath = _animationFrames[_currentFrame];
    
    // Scale the path to match component size
    final Matrix4 matrix = Matrix4.identity()
      ..scale(size.x / 50, size.y / 50); // Scale to fit component size
    
    final Path scaledPath = currentPath.transform(matrix.storage);
    
    // Draw the trap
    if (type == TrapType.laser) {
      TrapSprites.drawLaserToCanvas(canvas, scaledPath);
    } else {
      TrapSprites.drawTrapToCanvas(canvas, scaledPath, Colors.black);
    }
  }
  
  @override
  void update(double dt) {
    super.update(dt);
    
    // Update animation
    _updateAnimation(dt);
    
    // Update trap behavior based on type
    switch (type) {
      case TrapType.spike:
        // Static trap, no movement
        break;
      case TrapType.blade:
        // Rotating blade handled by animation
        break;
      case TrapType.laser:
        // Pulsing laser handled by animation
        break;
      case TrapType.fallingPlatform:
        _updateFallingPlatform(dt);
        break;
      case TrapType.crumblingPlatform:
        _updateCrumblingPlatform(dt);
        break;
    }
  }
  
  void _updateAnimation(double dt) {
    _animTimer += dt;
    
    if (_animTimer >= _frameDuration) {
      _animTimer = 0;
      
      // Special case for falling platform and crumbling platform
      if (type == TrapType.fallingPlatform && !_isFalling) {
        _currentFrame = 0; // Stay on first frame until triggered
      } else if (type == TrapType.crumblingPlatform && !_isCrumbling) {
        _currentFrame = 0; // Stay on first frame until triggered
      } else {
        // Normal animation cycling
        _currentFrame = (_currentFrame + 1) % _animationFrames.length;
      }
    }
  }
  
  void _updateFallingPlatform(double dt) {
    if (_isFalling) {
      // Apply gravity
      _fallSpeed += GameConstants.gravity * dt;
      position.y += _fallSpeed * dt;
      
      // Progress through animation frames
      if (_currentFrame < _animationFrames.length - 1 && _animTimer >= _frameDuration) {
        _currentFrame++;
        _animTimer = 0;
      }
      
      // Remove if fallen off screen
      if (position.y > gameRef.size.y + 100) {
        removeFromParent();
      }
    }
  }
  
  void _updateCrumblingPlatform(double dt) {
    if (_isCrumbling) {
      _crumbleTimer += dt;
      
      // Progress through animation frames
      if (_currentFrame < _animationFrames.length - 1 && _crumbleTimer >= _frameDuration * 2) {
        _currentFrame++;
        _crumbleTimer = 0;
      }
      
      // Deactivate after fully crumbled
      if (_currentFrame == _animationFrames.length - 1) {
        _isActive = false;
      }
    }
  }
  
  // Trigger falling platform
  void triggerFall() {
    if (type == TrapType.fallingPlatform && !_isFalling) {
      _isFalling = true;
      _currentFrame = 1; // Start falling animation
    }
  }
  
  // Trigger crumbling platform
  void triggerCrumble() {
    if (type == TrapType.crumblingPlatform && !_isCrumbling) {
      _isCrumbling = true;
      _currentFrame = 1; // Start crumbling animation
    }
  }
  
  // Deactivate trap (for one-time traps)
  void deactivate() {
    _isActive = false;
  }
}
