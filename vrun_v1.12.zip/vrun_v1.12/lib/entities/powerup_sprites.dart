import 'package:flutter/material.dart';

// This file will contain the power-up sprite data
// Since we're creating a minimalist black/white silhouette style,
// we'll create simple vector-based animations for power-ups

class PowerUpSprites {
  // Create shield power-up
  static List<Path> createShieldFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Shield normal
    final Path frame1 = Path();
    
    // Shield outer circle
    frame1.addOval(Rect.fromCircle(center: const Offset(25, 25), radius: 20));
    
    // Shield inner details
    frame1.moveTo(25, 5);
    frame1.lineTo(25, 45);
    
    frame1.moveTo(5, 25);
    frame1.lineTo(45, 25);
    
    frames.add(frame1);
    
    // Frame 2 - Shield pulsing
    final Path frame2 = Path();
    
    // Shield outer circle (slightly larger)
    frame2.addOval(Rect.fromCircle(center: const Offset(25, 25), radius: 22));
    
    // Shield inner details
    frame2.moveTo(25, 3);
    frame2.lineTo(25, 47);
    
    frame2.moveTo(3, 25);
    frame2.lineTo(47, 25);
    
    frames.add(frame2);
    
    return frames;
  }
  
  // Create slow motion power-up
  static List<Path> createSlowMotionFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Clock normal
    final Path frame1 = Path();
    
    // Clock outer circle
    frame1.addOval(Rect.fromCircle(center: const Offset(25, 25), radius: 20));
    
    // Clock hands
    frame1.moveTo(25, 25);
    frame1.lineTo(25, 10); // 12 o'clock
    
    frame1.moveTo(25, 25);
    frame1.lineTo(35, 25); // 3 o'clock
    
    frames.add(frame1);
    
    // Frame 2 - Clock hands moving
    final Path frame2 = Path();
    
    // Clock outer circle
    frame2.addOval(Rect.fromCircle(center: const Offset(25, 25), radius: 20));
    
    // Clock hands (rotated)
    frame2.moveTo(25, 25);
    frame2.lineTo(15, 25); // 9 o'clock
    
    frame2.moveTo(25, 25);
    frame2.lineTo(25, 40); // 6 o'clock
    
    frames.add(frame2);
    
    // Frame 3 - Clock with wave effect
    final Path frame3 = Path();
    
    // Clock outer circle
    frame3.addOval(Rect.fromCircle(center: const Offset(25, 25), radius: 20));
    
    // Clock hands
    frame3.moveTo(25, 25);
    frame3.lineTo(35, 15); // 2 o'clock
    
    frame3.moveTo(25, 25);
    frame3.lineTo(15, 35); // 8 o'clock
    
    // Wave effect
    frame3.moveTo(5, 25);
    frame3.cubicTo(10, 15, 15, 35, 20, 25);
    frame3.cubicTo(25, 15, 30, 35, 35, 25);
    frame3.cubicTo(40, 15, 45, 35, 50, 25);
    
    frames.add(frame3);
    
    return frames;
  }
  
  // Draw power-up to canvas
  static void drawPowerUpToCanvas(Canvas canvas, Path path, Color color) {
    final Paint paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    
    canvas.drawPath(path, paint);
  }
  
  // Draw shield effect around player
  static void drawShieldEffect(Canvas canvas, Rect bounds, double intensity) {
    final Paint paint = Paint()
      ..color = Colors.blue.withOpacity(0.3 * intensity)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3 * intensity;
    
    canvas.drawCircle(
      Offset(bounds.center.dx, bounds.center.dy),
      bounds.width / 1.5,
      paint,
    );
  }
  
  // Draw slow motion effect
  static void drawSlowMotionEffect(Canvas canvas, Rect bounds, double intensity) {
    final Paint paint = Paint()
      ..color = Colors.purple.withOpacity(0.2 * intensity)
      ..style = PaintingStyle.fill;
    
    canvas.drawRect(bounds, paint);
  }
}
