import 'dart:math'; // Import dart:math for max
import 'package:flame/components.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../controllers/game_controller.dart';
import '../controllers/settings_controller.dart'; // Import SettingsController
import '../core/constants.dart';
import '../core/enums.dart';
import 'player_sprites.dart';
import 'package:flame/input.dart'; // Import for KeyEvent handling
import 'package:vector_math/vector_math_64.dart' as vector_math;


class Player extends SpriteAnimationComponent with KeyboardHandler, HasGameRef {
  // Player state
  PlayerState _state = PlayerState.idle;
  PlayerState get state => _state;

  // Movement variables
  final double _baseSpeedX = GameConstants.playerSpeed;
  double _currentSpeedX = GameConstants.playerSpeed;
  double _speedY = 0;
  bool _isOnGround = true;
  bool _canDoubleJump = false;
  bool _isBowing = false;

  // Power-up states
  bool _hasShield = false;
  bool _isInSlowMotion = false;

  // Custom render function for vector-based animations
  final List<Path> _idleFrames = PlayerSprites.createIdleFrames();
  final List<Path> _runFrames = PlayerSprites.createRunFrames();
  final List<Path> _jumpFrames = PlayerSprites.createJumpFrames();
  final List<Path> _doubleJumpFrames = PlayerSprites.createDoubleJumpFrames();
  final List<Path> _bowFrames = PlayerSprites.createBowFrames();
  final List<Path> _deathFrames = PlayerSprites.createDeathFrames();

  // Current frame index for each animation
  int _currentIdleFrame = 0;
  int _currentRunFrame = 0;
  int _currentJumpFrame = 0;
  int _currentDoubleJumpFrame = 0;
  int _currentBowFrame = 0;
  int _currentDeathFrame = 0;

  // Animation timers
  double _idleAnimTimer = 0;
  double _runAnimTimer = 0;
  double _jumpAnimTimer = 0;
  double _doubleJumpAnimTimer = 0;
  double _bowAnimTimer = 0;
  double _deathAnimTimer = 0;

  // Animation frame durations
  final double _idleFrameDuration = 0.5; // Slower for idle
  final double _runFrameDuration = 0.1; // Faster for running
  final double _jumpFrameDuration = 0.2;
  final double _doubleJumpFrameDuration = 0.2;
  final double _bowFrameDuration = 0.2;
  final double _deathFrameDuration = 0.15; // Faster death animation

  // Controllers
  final GameController _gameController = Get.find<GameController>();
  final SettingsController _settingsController = Get.find<SettingsController>();

  // Constructor
  Player({
    required vector_math.Vector2 position,
    required vector_math.Vector2 size,
  }) : super(
          position: position,
          size: size,
          anchor: Anchor.bottomCenter,
        );

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    // Set initial state based on controller
    _setState(_gameController.controlMethod == ControlMethod.auto ? PlayerState.running : PlayerState.idle);
  }

  // Method to reset player state, called when level restarts
  void resetState() {
    _speedY = 0;
    _isOnGround = true;
    _canDoubleJump = false;
    _isBowing = false;
    _hasShield = false;
    _isInSlowMotion = false;
    position = vector_math.Vector2(100, gameRef.size.y - 50); // Reset position
    _setState(_gameController.controlMethod == ControlMethod.auto ? PlayerState.running : PlayerState.idle);
    _updateAnimation(); // Reset animation frames/timers
  }


  @override
  void render(Canvas canvas) {
    super.render(canvas); // Ensure super.render is called
    Path currentPath;

    switch (_state) {
      case PlayerState.idle:
        currentPath = _idleFrames[_currentIdleFrame];
        break;
      case PlayerState.running:
        currentPath = _runFrames[_currentRunFrame];
        break;
      case PlayerState.jumping:
        currentPath = _jumpFrames[_currentJumpFrame];
        break;
      case PlayerState.doubleJumping:
        currentPath = _doubleJumpFrames[_currentDoubleJumpFrame];
        break;
      case PlayerState.bowing:
        currentPath = _bowFrames[_currentBowFrame];
        break;
      case PlayerState.dying:
        currentPath = _deathFrames[_currentDeathFrame];
        break;
      default:
        currentPath = _idleFrames[0];
    }

    // Scale the path to match component size
    final Matrix4 matrix = Matrix4.identity()
      ..scale(size.x / 50, size.y / 80); // Scale to fit component size
    final Path scaledPath = currentPath.transform(matrix.storage);

    // Draw the player
    PlayerSprites.drawPlayerToCanvas(canvas, scaledPath, Colors.black);

    // Draw shield effect if active
    if (_hasShield) {
      final Paint shieldPaint = Paint()
        ..color = Colors.blue.withOpacity(0.3)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3;
      canvas.drawCircle(
        Offset(size.x / 2, -size.y / 2), // Adjust offset for bottomCenter anchor
        max(size.x, size.y) / 1.8, // Use dart:math max
        shieldPaint,
      );
    }

    // Draw slow motion effect if active
    if (_isInSlowMotion) {
      final Paint slowMotionPaint = Paint()
        ..color = Colors.purple.withOpacity(0.2)
        ..style = PaintingStyle.fill;
      canvas.drawRect(
        Rect.fromLTWH(0, -size.y, size.x, size.y), // Adjust rect for bottomCenter anchor
        slowMotionPaint,
      );
    }
  }

  @override
  void update(double dt) {
    super.update(dt);

    _updateAnimations(dt);

    // Apply gravity only if not dying
    if (_state != PlayerState.dying) {
      _speedY += GameConstants.gravity * dt;
    }

    // Update horizontal speed based on slow motion
    _currentSpeedX = _baseSpeedX * (_isInSlowMotion ? 0.5 : 1.0);

    // Apply movement based on control method
    if (_gameController.controlMethod == ControlMethod.auto && _state != PlayerState.dying) {
      position.x += _currentSpeedX * dt;
    }

    // Apply vertical movement
    position.y += _speedY * dt;

    // Simple ground check (replace with collision detection later)
    double groundLevel = gameRef.size.y - 50; // Example ground level
    if (position.y >= groundLevel && _state != PlayerState.dying) {
      position.y = groundLevel;
      if (!_isOnGround) {
        _isOnGround = true;
        _canDoubleJump = false;
        _speedY = 0;
        if (_isBowing) {
          _isBowing = false;
          _updateAnimation();
        } else if (_state != PlayerState.idle && _state != PlayerState.running) {
          _setState(_gameController.controlMethod == ControlMethod.auto ? PlayerState.running : PlayerState.idle);
        }
      }
    }

    // Prevent falling through floor if dying animation is playing
    if (_state == PlayerState.dying && position.y > groundLevel) {
      position.y = groundLevel;
      _speedY = 0;
    }
  }

  void _updateAnimations(double dt) {
    final frameDurationMultiplier = _isInSlowMotion ? 2.0 : 1.0;

    switch (_state) {
      case PlayerState.idle:
        _idleAnimTimer += dt;
        if (_idleAnimTimer >= _idleFrameDuration * frameDurationMultiplier) {
          _idleAnimTimer = 0;
          _currentIdleFrame = (_currentIdleFrame + 1) % _idleFrames.length;
        }
        break;
      case PlayerState.running:
        _runAnimTimer += dt;
        if (_runAnimTimer >= _runFrameDuration * frameDurationMultiplier) {
          _runAnimTimer = 0;
          _currentRunFrame = (_currentRunFrame + 1) % _runFrames.length;
        }
        break;
      case PlayerState.jumping:
        _jumpAnimTimer += dt;
        if (_jumpAnimTimer >= _jumpFrameDuration * frameDurationMultiplier) {
          _jumpAnimTimer = 0;
          if (_currentJumpFrame < _jumpFrames.length - 1) _currentJumpFrame++;
        }
        break;
      case PlayerState.doubleJumping:
        _doubleJumpAnimTimer += dt;
        if (_doubleJumpAnimTimer >= _doubleJumpFrameDuration * frameDurationMultiplier) {
          _doubleJumpAnimTimer = 0;
          if (_currentDoubleJumpFrame < _doubleJumpFrames.length - 1) _currentDoubleJumpFrame++;
        }
        break;
      case PlayerState.bowing:
        _bowAnimTimer += dt;
        if (_bowAnimTimer >= _bowFrameDuration * frameDurationMultiplier) {
          _bowAnimTimer = 0;
          if (_currentBowFrame < _bowFrames.length - 1) _currentBowFrame++;
        }
        break;
      case PlayerState.dying:
        _deathAnimTimer += dt;
        if (_deathAnimTimer >= _deathFrameDuration) {
          _deathAnimTimer = 0;
          if (_currentDeathFrame < _deathFrames.length - 1) {
            _currentDeathFrame++;
          } else {
            // Use gameController.gameState instead of _gameController.gameState.value
            if (_gameController.gameState != GameState.gameOver) {
              _gameController.setGameState(GameState.gameOver);
            }
          }
        }
        break;
    }
  }

  void jump() {
    if (_state == PlayerState.dying) return;
    if (_isOnGround) {
      _isOnGround = false;
      _canDoubleJump = true;
      _speedY = -GameConstants.jumpForce;
      _setState(PlayerState.jumping);
    } else if (_canDoubleJump) {
      _canDoubleJump = false;
      _speedY = -GameConstants.doubleJumpForce;
      _setState(PlayerState.doubleJumping);
    }
  }

  void bow() {
    if (_state == PlayerState.dying) return;
    if (_isOnGround && !_isBowing) {
      _isBowing = true;
      _setState(PlayerState.bowing);
    }
  }

  void stopBowing() {
    if (_isBowing) {
      _isBowing = false;
      _setState(_gameController.controlMethod == ControlMethod.auto || (_currentRunFrame > 0 && _gameController.controlMethod == ControlMethod.manual) ? PlayerState.running : PlayerState.idle);
    }
  }

  void moveLeft() {
    if (_state == PlayerState.dying) return;
    if (_gameController.controlMethod == ControlMethod.manual) {
      position.x -= _currentSpeedX * (1 / 60); // Use current speed, fixed timestep approx
      if (_isOnGround && !_isBowing) _setState(PlayerState.running);
    }
  }

  void moveRight() {
    if (_state == PlayerState.dying) return;
    if (_gameController.controlMethod == ControlMethod.manual) {
      position.x += _currentSpeedX * (1 / 60); // Use current speed, fixed timestep approx
      if (_isOnGround && !_isBowing) _setState(PlayerState.running);
    }
  }

  void stopMoving() {
    if (_state == PlayerState.dying) return;
    if (_gameController.controlMethod == ControlMethod.manual && _isOnGround && !_isBowing) {
      _setState(PlayerState.idle);
    }
  }

  @override
  bool onKeyEvent(KeyEvent event, Set<LogicalKeyboardKey> keysPressed) {
    if (_state == PlayerState.dying) return false;

    final isKeyDown = event is KeyDownEvent || event is KeyRepeatEvent;
    final isKeyUp = event is KeyUpEvent;

    if (event.logicalKey == LogicalKeyboardKey.space || event.logicalKey == LogicalKeyboardKey.arrowUp || event.logicalKey == LogicalKeyboardKey.keyW) {
      if (isKeyDown) jump();
      return true;
    }
    if (event.logicalKey == LogicalKeyboardKey.keyS || event.logicalKey == LogicalKeyboardKey.arrowDown) {
      if (isKeyDown) bow();
      else if (isKeyUp) stopBowing();
      return true;
    }

    if (_gameController.controlMethod == ControlMethod.manual) {
      bool handled = false;
      bool isMovingLeft = keysPressed.contains(LogicalKeyboardKey.keyA) || keysPressed.contains(LogicalKeyboardKey.arrowLeft);
      bool isMovingRight = keysPressed.contains(LogicalKeyboardKey.keyD) || keysPressed.contains(LogicalKeyboardKey.arrowRight);

      if (isKeyDown) {
        if (event.logicalKey == LogicalKeyboardKey.keyA || event.logicalKey == LogicalKeyboardKey.arrowLeft ||
            event.logicalKey == LogicalKeyboardKey.keyD || event.logicalKey == LogicalKeyboardKey.arrowRight) {
          handled = true; // Movement handled by continuous check
        }
      }
      if (isKeyUp) {
        if (event.logicalKey == LogicalKeyboardKey.keyA || event.logicalKey == LogicalKeyboardKey.arrowLeft ||
            event.logicalKey == LogicalKeyboardKey.keyD || event.logicalKey == LogicalKeyboardKey.arrowRight) {
          if (!isMovingLeft && !isMovingRight) stopMoving();
          handled = true;
        }
      }

      // Continuous check (ideally in update, but approximated here)
      if (isMovingLeft && !isMovingRight) moveLeft();
      else if (isMovingRight && !isMovingLeft) moveRight();
      else if (!isMovingLeft && !isMovingRight && _state == PlayerState.running) stopMoving();

      if (handled) return true;
    }
    return false;
  }

  void _setState(PlayerState newState) {
    if (_state != newState && _state != PlayerState.dying) {
      _state = newState;
      _updateAnimation();
    }
  }

  void _updateAnimation() {
    _idleAnimTimer = 0; _currentIdleFrame = 0;
    _runAnimTimer = 0; _currentRunFrame = 0;
    _jumpAnimTimer = 0; _currentJumpFrame = 0;
    _doubleJumpAnimTimer = 0; _currentDoubleJumpFrame = 0;
    _bowAnimTimer = 0; _currentBowFrame = 0;
    if (_state != PlayerState.dying) {
      _deathAnimTimer = 0; _currentDeathFrame = 0;
    }
  }

  void collidedWithTrap() {
    if (_state == PlayerState.dying) return;
    if (_hasShield) {
      _hasShield = false;
      _gameController.setShield(false);
    } else {
      _setState(PlayerState.dying);
      // _speedX = 0; // Removed assignment to final field
      _speedY = -GameConstants.jumpForce / 3; // Smaller bounce on death
    }
  }

  void collectShield() {
    if (_state == PlayerState.dying) return;
    _hasShield = true;
    _gameController.setShield(true);
  }

  void collectSlowMotion() {
    if (_state == PlayerState.dying) return;
    if (!_isInSlowMotion) {
      _isInSlowMotion = true;
      _gameController.setSlowMotion(true);
      gameRef.add(TimerComponent(period: GameConstants.slowMotionDuration, onTick: () {
        _isInSlowMotion = false;
        _gameController.setSlowMotion(false);
      }, removeOnFinish: true));
    }
  }
}

