import 'package:flutter/material.dart';

// This file will contain the player character sprite data
// Since we're creating a minimalist black/white silhouette style,
// we'll create simple vector-based animations

class PlayerSprites {
  // Create a simple humanoid silhouette for the player
  static Path createPlayerSilhouette() {
    final Path path = Path();
    
    // Head
    path.addOval(Rect.fromCircle(center: const Offset(25, 15), radius: 10));
    
    // Body
    path.moveTo(25, 25);
    path.lineTo(25, 50);
    
    // Arms
    path.moveTo(25, 30);
    path.lineTo(15, 40); // Left arm
    path.moveTo(25, 30);
    path.lineTo(35, 40); // Right arm
    
    // Legs
    path.moveTo(25, 50);
    path.lineTo(15, 70); // Left leg
    path.moveTo(25, 50);
    path.lineTo(35, 70); // Right leg
    
    return path;
  }
  
  // Create idle animation frames
  static List<Path> createIdleFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Default pose
    final Path frame1 = createPlayerSilhouette();
    frames.add(frame1);
    
    // Frame 2 - Slight breathing movement
    final Path frame2 = Path();
    // Head
    frame2.addOval(Rect.fromCircle(center: const Offset(25, 15), radius: 10));
    // Body - slightly shorter for breathing effect
    frame2.moveTo(25, 25);
    frame2.lineTo(25, 49);
    // Arms
    frame2.moveTo(25, 30);
    frame2.lineTo(15, 39); // Left arm
    frame2.moveTo(25, 30);
    frame2.lineTo(35, 39); // Right arm
    // Legs
    frame2.moveTo(25, 49);
    frame2.lineTo(15, 70); // Left leg
    frame2.moveTo(25, 49);
    frame2.lineTo(35, 70); // Right leg
    frames.add(frame2);
    
    return frames;
  }
  
  // Create running animation frames
  static List<Path> createRunFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Running pose 1
    final Path frame1 = Path();
    // Head
    frame1.addOval(Rect.fromCircle(center: const Offset(25, 15), radius: 10));
    // Body
    frame1.moveTo(25, 25);
    frame1.lineTo(25, 50);
    // Arms - running position
    frame1.moveTo(25, 30);
    frame1.lineTo(15, 25); // Left arm up
    frame1.moveTo(25, 30);
    frame1.lineTo(35, 45); // Right arm down
    // Legs - running position
    frame1.moveTo(25, 50);
    frame1.lineTo(15, 65); // Left leg forward
    frame1.moveTo(25, 50);
    frame1.lineTo(35, 55); // Right leg back
    frames.add(frame1);
    
    // Frame 2 - Running pose 2
    final Path frame2 = Path();
    // Head
    frame2.addOval(Rect.fromCircle(center: const Offset(25, 15), radius: 10));
    // Body
    frame2.moveTo(25, 25);
    frame2.lineTo(25, 50);
    // Arms - running position (opposite)
    frame2.moveTo(25, 30);
    frame2.lineTo(15, 45); // Left arm down
    frame2.moveTo(25, 30);
    frame2.lineTo(35, 25); // Right arm up
    // Legs - running position (opposite)
    frame2.moveTo(25, 50);
    frame2.lineTo(15, 55); // Left leg back
    frame2.moveTo(25, 50);
    frame2.lineTo(35, 65); // Right leg forward
    frames.add(frame2);
    
    return frames;
  }
  
  // Create jumping animation frames
  static List<Path> createJumpFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Jump preparation
    final Path frame1 = Path();
    // Head
    frame1.addOval(Rect.fromCircle(center: const Offset(25, 20), radius: 10));
    // Body - crouched
    frame1.moveTo(25, 30);
    frame1.lineTo(25, 45);
    // Arms - ready to jump
    frame1.moveTo(25, 35);
    frame1.lineTo(15, 30); // Left arm up
    frame1.moveTo(25, 35);
    frame1.lineTo(35, 30); // Right arm up
    // Legs - crouched
    frame1.moveTo(25, 45);
    frame1.lineTo(15, 55); // Left leg bent
    frame1.moveTo(25, 45);
    frame1.lineTo(35, 55); // Right leg bent
    frames.add(frame1);
    
    // Frame 2 - Mid-jump
    final Path frame2 = Path();
    // Head
    frame2.addOval(Rect.fromCircle(center: const Offset(25, 15), radius: 10));
    // Body - stretched
    frame2.moveTo(25, 25);
    frame2.lineTo(25, 50);
    // Arms - stretched up
    frame2.moveTo(25, 30);
    frame2.lineTo(15, 20); // Left arm up
    frame2.moveTo(25, 30);
    frame2.lineTo(35, 20); // Right arm up
    // Legs - stretched
    frame2.moveTo(25, 50);
    frame2.lineTo(15, 60); // Left leg down
    frame2.moveTo(25, 50);
    frame2.lineTo(35, 60); // Right leg down
    frames.add(frame2);
    
    return frames;
  }
  
  // Create double jump animation frames
  static List<Path> createDoubleJumpFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Double jump preparation
    final Path frame1 = Path();
    // Head
    frame1.addOval(Rect.fromCircle(center: const Offset(25, 15), radius: 10));
    // Body - mid-air
    frame1.moveTo(25, 25);
    frame1.lineTo(25, 50);
    // Arms - ready for second jump
    frame1.moveTo(25, 30);
    frame1.lineTo(10, 25); // Left arm extended
    frame1.moveTo(25, 30);
    frame1.lineTo(40, 25); // Right arm extended
    // Legs - tucked for second jump
    frame1.moveTo(25, 50);
    frame1.lineTo(20, 60); // Left leg
    frame1.moveTo(25, 50);
    frame1.lineTo(30, 60); // Right leg
    frames.add(frame1);
    
    // Frame 2 - Double jump execution
    final Path frame2 = Path();
    // Head
    frame2.addOval(Rect.fromCircle(center: const Offset(25, 10), radius: 10));
    // Body - fully extended
    frame2.moveTo(25, 20);
    frame2.lineTo(25, 45);
    // Arms - fully extended
    frame2.moveTo(25, 25);
    frame2.lineTo(10, 15); // Left arm up and out
    frame2.moveTo(25, 25);
    frame2.lineTo(40, 15); // Right arm up and out
    // Legs - split
    frame2.moveTo(25, 45);
    frame2.lineTo(15, 65); // Left leg down and out
    frame2.moveTo(25, 45);
    frame2.lineTo(35, 65); // Right leg down and out
    frames.add(frame2);
    
    return frames;
  }
  
  // Create bow animation frames
  static List<Path> createBowFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Bow preparation
    final Path frame1 = Path();
    // Head - starting to bow
    frame1.addOval(Rect.fromCircle(center: const Offset(25, 20), radius: 10));
    // Body - starting to bend
    frame1.moveTo(25, 30);
    frame1.lineTo(25, 50);
    // Arms - starting to reach down
    frame1.moveTo(25, 35);
    frame1.lineTo(15, 45); // Left arm
    frame1.moveTo(25, 35);
    frame1.lineTo(35, 45); // Right arm
    // Legs - starting to bend
    frame1.moveTo(25, 50);
    frame1.lineTo(15, 65); // Left leg
    frame1.moveTo(25, 50);
    frame1.lineTo(35, 65); // Right leg
    frames.add(frame1);
    
    // Frame 2 - Full bow
    final Path frame2 = Path();
    // Head - fully bowed
    frame2.addOval(Rect.fromCircle(center: const Offset(25, 30), radius: 10));
    // Body - fully bent
    frame2.moveTo(25, 40);
    frame2.lineTo(25, 50);
    // Arms - reaching ground
    frame2.moveTo(25, 45);
    frame2.lineTo(15, 60); // Left arm
    frame2.moveTo(25, 45);
    frame2.lineTo(35, 60); // Right arm
    // Legs - fully bent
    frame2.moveTo(25, 50);
    frame2.lineTo(15, 60); // Left leg
    frame2.moveTo(25, 50);
    frame2.lineTo(35, 60); // Right leg
    frames.add(frame2);
    
    return frames;
  }
  
  // Create death animation frames
  static List<Path> createDeathFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Death start
    final Path frame1 = Path();
    // Head - shocked
    frame1.addOval(Rect.fromCircle(center: const Offset(25, 15), radius: 10));
    // Body - starting to fall
    frame1.moveTo(25, 25);
    frame1.lineTo(25, 50);
    // Arms - thrown up
    frame1.moveTo(25, 30);
    frame1.lineTo(10, 20); // Left arm up
    frame1.moveTo(25, 30);
    frame1.lineTo(40, 20); // Right arm up
    // Legs - starting to collapse
    frame1.moveTo(25, 50);
    frame1.lineTo(20, 65); // Left leg
    frame1.moveTo(25, 50);
    frame1.lineTo(30, 65); // Right leg
    frames.add(frame1);
    
    // Frame 2 - Death middle
    final Path frame2 = Path();
    // Head - falling
    frame2.addOval(Rect.fromCircle(center: const Offset(25, 25), radius: 10));
    // Body - falling
    frame2.moveTo(25, 35);
    frame2.lineTo(25, 55);
    // Arms - flailing
    frame2.moveTo(25, 40);
    frame2.lineTo(10, 35); // Left arm
    frame2.moveTo(25, 40);
    frame2.lineTo(40, 35); // Right arm
    // Legs - collapsing
    frame2.moveTo(25, 55);
    frame2.lineTo(15, 60); // Left leg
    frame2.moveTo(25, 55);
    frame2.lineTo(35, 60); // Right leg
    frames.add(frame2);
    
    // Frame 3 - Death end
    final Path frame3 = Path();
    // Head - on ground
    frame3.addOval(Rect.fromCircle(center: const Offset(25, 60), radius: 10));
    // Body - on ground
    frame3.moveTo(25, 60);
    frame3.lineTo(25, 65);
    // Arms - splayed
    frame3.moveTo(25, 60);
    frame3.lineTo(10, 55); // Left arm
    frame3.moveTo(25, 60);
    frame3.lineTo(40, 55); // Right arm
    // Legs - splayed
    frame3.moveTo(25, 65);
    frame3.lineTo(15, 70); // Left leg
    frame3.moveTo(25, 65);
    frame3.lineTo(35, 70); // Right leg
    frames.add(frame3);
    
    return frames;
  }
  
  // Draw player silhouette to canvas
  static void drawPlayerToCanvas(Canvas canvas, Path path, Color color) {
    final Paint paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    
    canvas.drawPath(path, paint);
    
    // Add eyes (white dots)
    final Paint eyePaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.fill;
    
    canvas.drawCircle(const Offset(22, 15), 2, eyePaint); // Left eye
    canvas.drawCircle(const Offset(28, 15), 2, eyePaint); // Right eye
  }
}
