import 'package:flutter/material.dart';

// This file will contain the trap sprite data
// Since we're creating a minimalist black/white silhouette style,
// we'll create simple vector-based animations for traps

class TrapSprites {
  // Create static spike trap
  static Path createSpikeTrap() {
    final Path path = Path();
    
    // Base
    path.moveTo(0, 50);
    path.lineTo(50, 50);
    
    // Spikes
    for (int i = 0; i < 5; i++) {
      final double x = i * 10 + 5;
      path.moveTo(x, 50);
      path.lineTo(x + 5, 20);
      path.lineTo(x + 10, 50);
    }
    
    return path;
  }
  
  // Create blade trap frames
  static List<Path> createBladeFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Blade at 0 degrees
    final Path frame1 = Path();
    // Center
    frame1.addOval(Rect.fromCircle(center: const Offset(25, 25), radius: 5));
    // Blade
    frame1.moveTo(25, 25);
    frame1.lineTo(5, 5);
    frame1.lineTo(10, 0);
    frame1.lineTo(30, 20);
    frame1.lineTo(25, 25);
    
    frame1.moveTo(25, 25);
    frame1.lineTo(45, 5);
    frame1.lineTo(50, 10);
    frame1.lineTo(30, 30);
    frame1.lineTo(25, 25);
    
    frame1.moveTo(25, 25);
    frame1.lineTo(45, 45);
    frame1.lineTo(40, 50);
    frame1.lineTo(20, 30);
    frame1.lineTo(25, 25);
    
    frame1.moveTo(25, 25);
    frame1.lineTo(5, 45);
    frame1.lineTo(0, 40);
    frame1.lineTo(20, 20);
    frame1.lineTo(25, 25);
    
    frames.add(frame1);
    
    // Frame 2 - Blade at 45 degrees
    final Path frame2 = Path();
    // Center
    frame2.addOval(Rect.fromCircle(center: const Offset(25, 25), radius: 5));
    // Blade rotated 45 degrees
    frame2.moveTo(25, 25);
    frame2.lineTo(15, 5);
    frame2.lineTo(20, 0);
    frame2.lineTo(30, 20);
    frame2.lineTo(25, 25);
    
    frame2.moveTo(25, 25);
    frame2.lineTo(45, 15);
    frame2.lineTo(50, 20);
    frame2.lineTo(30, 30);
    frame2.lineTo(25, 25);
    
    frame2.moveTo(25, 25);
    frame2.lineTo(35, 45);
    frame2.lineTo(30, 50);
    frame2.lineTo(20, 30);
    frame2.lineTo(25, 25);
    
    frame2.moveTo(25, 25);
    frame2.lineTo(5, 35);
    frame2.lineTo(0, 30);
    frame2.lineTo(20, 20);
    frame2.lineTo(25, 25);
    
    frames.add(frame2);
    
    return frames;
  }
  
  // Create laser beam frames
  static List<Path> createLaserFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Laser beam on
    final Path frame1 = Path();
    // Emitter base
    frame1.addRect(const Rect.fromLTWH(0, 20, 10, 10));
    // Beam
    frame1.moveTo(10, 25);
    frame1.lineTo(50, 25);
    frame1.lineTo(50, 27);
    frame1.lineTo(10, 27);
    frame1.close();
    
    frames.add(frame1);
    
    // Frame 2 - Laser beam pulsing
    final Path frame2 = Path();
    // Emitter base
    frame2.addRect(const Rect.fromLTWH(0, 20, 10, 10));
    // Beam (slightly thinner)
    frame2.moveTo(10, 25.5);
    frame2.lineTo(50, 25.5);
    frame2.lineTo(50, 26.5);
    frame2.lineTo(10, 26.5);
    frame2.close();
    
    frames.add(frame2);
    
    return frames;
  }
  
  // Create falling platform frames
  static List<Path> createFallingPlatformFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Platform stable
    final Path frame1 = Path();
    // Platform
    frame1.addRect(const Rect.fromLTWH(0, 0, 50, 10));
    
    frames.add(frame1);
    
    // Frame 2 - Platform tilting
    final Path frame2 = Path();
    // Platform tilting
    frame2.moveTo(5, 0);
    frame2.lineTo(45, 5);
    frame2.lineTo(45, 15);
    frame2.lineTo(5, 10);
    frame2.close();
    
    frames.add(frame2);
    
    // Frame 3 - Platform falling
    final Path frame3 = Path();
    // Platform falling
    frame3.moveTo(0, 10);
    frame3.lineTo(50, 10);
    frame3.lineTo(50, 20);
    frame3.lineTo(0, 20);
    frame3.close();
    
    frames.add(frame3);
    
    return frames;
  }
  
  // Create crumbling platform frames
  static List<Path> createCrumblingPlatformFrames() {
    final List<Path> frames = [];
    
    // Frame 1 - Platform intact
    final Path frame1 = Path();
    // Platform
    frame1.addRect(const Rect.fromLTWH(0, 0, 50, 10));
    
    frames.add(frame1);
    
    // Frame 2 - Platform cracking
    final Path frame2 = Path();
    // Platform with cracks
    frame2.addRect(const Rect.fromLTWH(0, 0, 50, 10));
    // Cracks
    frame2.moveTo(10, 0);
    frame2.lineTo(15, 10);
    
    frame2.moveTo(25, 0);
    frame2.lineTo(20, 10);
    
    frame2.moveTo(35, 0);
    frame2.lineTo(40, 10);
    
    frames.add(frame2);
    
    // Frame 3 - Platform breaking apart
    final Path frame3 = Path();
    // Platform pieces
    frame3.addRect(const Rect.fromLTWH(0, 0, 10, 10));
    frame3.addRect(const Rect.fromLTWH(15, 2, 10, 10));
    frame3.addRect(const Rect.fromLTWH(30, 1, 10, 10));
    frame3.addRect(const Rect.fromLTWH(45, 3, 5, 10));
    
    frames.add(frame3);
    
    // Frame 4 - Platform completely crumbled
    final Path frame4 = Path();
    // Small debris
    frame4.addRect(const Rect.fromLTWH(5, 5, 5, 5));
    frame4.addRect(const Rect.fromLTWH(20, 7, 5, 5));
    frame4.addRect(const Rect.fromLTWH(35, 6, 5, 5));
    
    frames.add(frame4);
    
    return frames;
  }
  
  // Draw trap to canvas
  static void drawTrapToCanvas(Canvas canvas, Path path, Color color) {
    final Paint paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;
    
    canvas.drawPath(path, paint);
  }
  
  // Draw laser to canvas (with red color)
  static void drawLaserToCanvas(Canvas canvas, Path path) {
    final Paint paint = Paint()
      ..color = Colors.red
      ..style = PaintingStyle.fill;
    
    canvas.drawPath(path, paint);
  }
}
