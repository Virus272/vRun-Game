import 'dart:ui' as ui;
import 'package:flame/components.dart';
import 'package:flame/parallax.dart';
import 'package:flutter/material.dart'; // Keep for Colors
import '../core/constants.dart';
import 'package:vector_math/vector_math_64.dart' as vector_math;

class ParallaxBackground extends ParallaxComponent with HasGameRef {
  // Background layers
  late ParallaxLayer _farLayer;
  late ParallaxLayer _midLayer;
  late ParallaxLayer _nearLayer;

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    // Create parallax layers
    parallax = await _createParallax();
  }

  Future<Parallax> _createParallax() async {
    // Create vector-based parallax backgrounds

    // Far layer - distant mountains/hills
    final farLayerImage = await _createFarLayerImage();
    _farLayer = ParallaxLayer(
      ParallaxImage(farLayerImage, fill: LayerFill.width),
      velocityMultiplier: vector_math.Vector2(0.1, 0),
    );

    // Mid layer - closer hills/structures
    final midLayerImage = await _createMidLayerImage();
    _midLayer = ParallaxLayer(
      ParallaxImage(midLayerImage, fill: LayerFill.width),
      velocityMultiplier: vector_math.Vector2(0.3, 0),
    );

    // Near layer - ground details
    final nearLayerImage = await _createNearLayerImage();
    _nearLayer = ParallaxLayer(
      ParallaxImage(nearLayerImage, fill: LayerFill.width),
      velocityMultiplier: vector_math.Vector2(0.5, 0),
    );

    return Parallax(
      [_farLayer, _midLayer, _nearLayer],
      baseVelocity: vector_math.Vector2(50, 0),
    );
  }

  Future<ui.Image> _createFarLayerImage() async {
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    const size = ui.Size(GameConstants.gameWidth * 1.5, GameConstants.gameHeight);

    final bgPaint = ui.Paint()
      ..color = Colors.grey[200]!
      ..style = ui.PaintingStyle.fill;
    canvas.drawRect(ui.Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    final mountainPaint = ui.Paint()
      ..color = Colors.grey[300]!
      ..style = ui.PaintingStyle.fill;

    final mountainPath = ui.Path();
    mountainPath.moveTo(0, size.height * 0.7);
    for (int i = 0; i < 10; i++) {
      final peakX = size.width * (i / 10) + (size.width / 20);
      final peakY = size.height * 0.5 + (i % 3) * 20;
      mountainPath.lineTo(peakX, peakY);
      final valleyX = size.width * ((i + 0.5) / 10);
      final valleyY = size.height * 0.65 + (i % 2) * 10;
      mountainPath.lineTo(valleyX, valleyY);
    }
    mountainPath.lineTo(size.width, size.height * 0.7);
    mountainPath.lineTo(size.width, size.height);
    mountainPath.lineTo(0, size.height);
    mountainPath.close();
    canvas.drawPath(mountainPath, mountainPaint);

    final picture = recorder.endRecording();
    final img = await picture.toImage(size.width.toInt(), size.height.toInt());
    return img;
  }

  Future<ui.Image> _createMidLayerImage() async {
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    const size = ui.Size(GameConstants.gameWidth * 1.5, GameConstants.gameHeight);

    final bgPaint = ui.Paint()
      ..color = Colors.transparent
      ..style = ui.PaintingStyle.fill;
    canvas.drawRect(ui.Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    final hillPaint = ui.Paint()
      ..color = Colors.grey[400]!
      ..style = ui.PaintingStyle.fill;

    final hillPath = ui.Path();
    hillPath.moveTo(0, size.height * 0.8);
    for (int i = 0; i < 15; i++) {
      final peakX = size.width * (i / 15) + (size.width / 30);
      final peakY = size.height * 0.65 + (i % 4) * 15;
      hillPath.lineTo(peakX, peakY);
      final valleyX = size.width * ((i + 0.5) / 15);
      final valleyY = size.height * 0.75 + (i % 3) * 10;
      hillPath.lineTo(valleyX, valleyY);
    }
    hillPath.lineTo(size.width, size.height * 0.8);
    hillPath.lineTo(size.width, size.height);
    hillPath.lineTo(0, size.height);
    hillPath.close();
    canvas.drawPath(hillPath, hillPaint);

    final structurePaint = ui.Paint()
      ..color = Colors.grey[500]!
      ..style = ui.PaintingStyle.fill;

    for (int i = 0; i < 5; i++) {
      final buildingX = size.width * (i / 5) + 100;
      final buildingWidth = 30.0 + (i % 3) * 10.0; // Use double
      final buildingHeight = 50.0 + (i % 4) * 20.0; // Use double
      final buildingY = size.height * 0.75 - buildingHeight;
      canvas.drawRect(
        ui.Rect.fromLTWH(buildingX, buildingY, buildingWidth, buildingHeight),
        structurePaint,
      );
    }

    final picture = recorder.endRecording();
    final img = await picture.toImage(size.width.toInt(), size.height.toInt());
    return img;
  }

  Future<ui.Image> _createNearLayerImage() async {
    final recorder = ui.PictureRecorder();
    final canvas = ui.Canvas(recorder);
    const size = ui.Size(GameConstants.gameWidth * 1.5, GameConstants.gameHeight);

    final bgPaint = ui.Paint()
      ..color = Colors.transparent
      ..style = ui.PaintingStyle.fill;
    canvas.drawRect(ui.Rect.fromLTWH(0, 0, size.width, size.height), bgPaint);

    final groundPaint = ui.Paint()
      ..color = Colors.grey[600]!
      ..style = ui.PaintingStyle.fill;

    final groundPath = ui.Path();
    groundPath.moveTo(0, size.height * 0.95);
    for (int i = 0; i < 30; i++) {
      final pointX = size.width * (i / 30);
      final pointY = size.height * 0.95 + (i % 2) * 3;
      groundPath.lineTo(pointX, pointY);
    }
    groundPath.lineTo(size.width, size.height * 0.95);
    groundPath.lineTo(size.width, size.height);
    groundPath.lineTo(0, size.height);
    groundPath.close();
    canvas.drawPath(groundPath, groundPaint);

    final detailPaint = ui.Paint()
      ..color = Colors.grey[700]!
      ..style = ui.PaintingStyle.fill;

    for (int i = 0; i < 20; i++) {
      final rockX = size.width * (i / 20) + (i % 5) * 10;
      final rockSize = 5.0 + (i % 3) * 3.0; // Use double
      final rockY = size.height * 0.95 - rockSize;
      canvas.drawCircle(
        ui.Offset(rockX, rockY),
        rockSize, // Already double
        detailPaint,
      );
    }

    final picture = recorder.endRecording();
    final img = await picture.toImage(size.width.toInt(), size.height.toInt());
    return img;
  }
}

