import 'dart:math';
import 'package:flame/components.dart';
import 'package:flame/particles.dart';
import 'package:flutter/material.dart';

// Helper function to create a ParticleSystemComponent from particle details
ParticleSystemComponent _createParticleSystem({
  required Vector2 position,
  required int count,
  required double lifespan,
  required Particle Function(int) generator,
}) {
  return ParticleSystemComponent(
    position: position,
    particle: Particle.generate(
      count: count,
      lifespan: lifespan,
      generator: generator,
    ),
  );
}

class ParticleEffects {
  static final Random _random = Random();

  // Jump particle effect
  static ParticleSystemComponent createJumpEffect(Vector2 position) {
    return _createParticleSystem(
      position: position,
      count: 10,
      lifespan: 0.5,
      generator: (i) => AcceleratedParticle(
        acceleration: Vector2(0, 200), // Increased gravity effect
        speed: Vector2(
          _random.nextDouble() * 60 - 30, // Random X velocity
          _random.nextDouble() * -80 - 20, // Stronger upward Y velocity
        ),
        child: CircleParticle(
          radius: 1 + _random.nextDouble() * 1.5,
          paint: Paint()..color = Colors.grey.withOpacity(0.6),
        ),
      ),
    );
  }

  // Landing particle effect
  static ParticleSystemComponent createLandingEffect(Vector2 position) {
    return _createParticleSystem(
      position: position,
      count: 15,
      lifespan: 0.6,
      generator: (i) => AcceleratedParticle(
        acceleration: Vector2(0, -50), // Slight upward drift initially
        speed: Vector2(
          _random.nextDouble() * 80 - 40, // Wider X spread
          _random.nextDouble() * -30, // Slight upward Y velocity
        ),
        child: CircleParticle(
          radius: 1 + _random.nextDouble() * 2.5,
          paint: Paint()..color = Colors.grey.withOpacity(0.7),
        ),
      ),
    );
  }

  // Death particle effect
  static ParticleSystemComponent createDeathEffect(Vector2 position, Vector2 size) {
    return _createParticleSystem(
      // Position is handled by the ParticleSystemComponent itself
      position: position + size / 2, // Start from center of player
      count: 60, // More particles for a more dramatic effect
      lifespan: 1.2,
      generator: (i) {
        final angle = _random.nextDouble() * 2 * pi;
        final speedMagnitude = _random.nextDouble() * 150 + 50; // Outward burst
        return AcceleratedParticle(
          acceleration: Vector2(0, 300), // Stronger gravity
          speed: Vector2(cos(angle) * speedMagnitude, sin(angle) * speedMagnitude),
          // Position relative to the ParticleSystemComponent's position
          position: Vector2(
            (_random.nextDouble() - 0.5) * size.x * 0.8, // Spread within player bounds
            (_random.nextDouble() - 0.5) * size.y * 0.8,
          ),
          child: CircleParticle(
            radius: 1 + _random.nextDouble() * 2,
            paint: Paint()..color = Colors.black.withOpacity(0.9),
          ),
        );
      },
    );
  }

  // Level completion particle effect
  static ParticleSystemComponent createVictoryEffect(Vector2 position) {
    return _createParticleSystem(
      position: position,
      count: 40,
      lifespan: 2.5,
      generator: (i) => AcceleratedParticle(
        acceleration: Vector2(0, -80), // Make particles float up
        speed: Vector2(
          _random.nextDouble() * 120 - 60, // Wider X spread
          _random.nextDouble() * -150 - 50, // Stronger upward Y velocity
        ),
        child: CircleParticle(
          radius: 2 + _random.nextDouble() * 3,
          paint: Paint()..color = Colors.white.withOpacity(0.8),
        ),
      ),
    );
  }

  // Power-up collection effect
  static ParticleSystemComponent createPowerUpEffect(Vector2 position, Color color) {
    return _createParticleSystem(
      position: position,
      count: 25,
      lifespan: 0.8,
      generator: (i) {
         final angle = _random.nextDouble() * 2 * pi;
         final speedMagnitude = _random.nextDouble() * 100 + 30;
         return AcceleratedParticle(
            acceleration: Vector2(0, 50), // Slight gravity
            speed: Vector2(cos(angle) * speedMagnitude, sin(angle) * speedMagnitude),
            child: CircleParticle(
              radius: 1.5 + _random.nextDouble() * 2,
              paint: Paint()..color = color.withOpacity(0.7),
            ),
         );
      }
    );
  }

  // Trap activation effect (for crumbling platforms, etc.)
  static ParticleSystemComponent createTrapActivationEffect(Vector2 position, Vector2 size) {
    return _createParticleSystem(
      position: position + Vector2(size.x / 2, 0), // Start from top-center
      count: 20,
      lifespan: 1.0,
      generator: (i) => AcceleratedParticle(
        acceleration: Vector2(0, 400), // Strong gravity for debris
        position: Vector2( // Spawn within the platform width
          (_random.nextDouble() - 0.5) * size.x,
          _random.nextDouble() * 5, // Slight vertical spread at start
        ),
        speed: Vector2(
          _random.nextDouble() * 50 - 25, // Random X velocity
          _random.nextDouble() * -50, // Initial upward pop
        ),
        // Use CircleParticle instead of RectangleParticle
        child: CircleParticle(
          radius: 1 + _random.nextDouble() * 2, // Adjust size as needed
          paint: Paint()..color = Colors.grey[700]!.withOpacity(0.8),
        ),
      ),
    );
  }
}

